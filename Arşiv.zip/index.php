<?php
// Deliberately compatible with older PHP parsers: show a useful version message first.
define('MOBISHOP_ENTRY', true);
if (!is_file(__DIR__.'/app/runtime.php')) { http_response_code(503); exit('MobiShop: paket natamamdir. app/runtime.php faylini ZIP-den domenin web kokune yukleyin.'); }
require __DIR__ . '/app/runtime.php';
mshop_safety_net();
mshop_require_runtime();
try {
    require __DIR__ . '/app/router.php';
} catch (Throwable $error) {
    mshop_failure($error);
}
