# MobiShop Niyazi — istifadə və uçot qaydaları

Quraşdırma üçün kök `README.md` faylına baxın.

## İlk iş axını

### Alış və satış

1. Mağaza seçin, kassanı açın.
2. Məhsul kartında SKU və satış qiymətini daxil edin. Adi məhsulun stokunu kart redaktəsi ilə dəyişməyin.
3. **Alış → Yeni sənəd**: məhsul, miqdar, real alış qiyməti, təchizatçı və ödəniş bölgüsü.
4. Təsdiqdən sonra stok artır, ödənilmiş məbləğ kassadan çıxır, ödənilməmiş hissə borc olur.
5. **POS / Satış**: ad, SKU, barkod və ya IMEI ilə axtarın. USB skaner klaviatura kimi barkodu yazıb Enter göndərə bilər.
6. Səbətə məhsul əlavə edin. Endirim icazəsi və limiti serverdə yoxlanır. Nağd/kart/bank bölgüsünü yazın və ya "Tam nağd" / "Tam kart" seçin.
7. Borclu satış üçün müştəri seçilməsi məcburidir. Alınan pulun artıq hissəsini ödəniş kimi yazmayın; müştəriyə qaytarılan pulu çıxıb faktiki qəbul olunan məbləği daxil edin.
8. Satış sənədi stok hərəkəti, kassa qeydi, işçi/mağaza statistikası və audit yaradır.

### Qaytarma

Satış sənədini açın → məhsul sətrini, miqdarı və səbəbi seçin. Geri məbləği server ilkin endirimə uyğun hesablayır. Qaytarılan stok ilkin satışın maya dəyəri ilə geri daxil olur. Ödənilmiş hissə müştəriyə qaytarılır; ödənilməmiş hissə borcdan silinir. Qaytarma əvvəlki ödənişlərə görə qalıq borc və kassanın mənfi olmaması yoxlanılmaqla qeydə alınır.

### Transfer

Göndərmə zamanı stok göndərən mağazadan çıxır, lakin qarşı mağazaya daxil olmur. Qəbul edən mağazaya icazəsi olan istifadəçi sənəddə **Qəbulu təsdiqlə** seçməlidir. Qəbuldan əvvəl göndərən tərəf ləğv edə bilər; stok geri qaytarılır. Transferdə maya dəyəri qorunur.

### Sayım

Faktiki sayları daxil edin → sənədi saxlayın → ayrıca təsdiqləyin. Saxlama ilə təsdiq arasında stok dəyişibsə köhnə sayım rədd olunur; yeni sayım yaradın. IMEI-li məhsulun stokunu sayımla artırmaq/azaltmaq qadağandır; fiziki IMEI problemi ayrıca araşdırılmalıdır.

### Servis

Müştəri seçin, model/IMEI, problem, təxmini qiymət və ustanı yazın. Sənəddə hissə seçib istifadə edin: stok dərhal azalır. Qəbul → diaqnostika → təmir / hissə gözlənilməsi → hazır → təhvil statusları serverdə yoxlanır. **Hazırdır** mərhələsində əmək haqqı daxil edilir. Sonra borc ödənişi qəbul edilə bilər. Ləğv ödənişdən və hazır statusundan əvvəl mümkündür; hissələr stoka qaytarılır. Hissə geri istifadəyə yararlı deyilsə bu qayda ilə ləğv etməyin.

### IMEI / ikinci əl

Məhsulda IMEI izləməsini aktiv edin. Alış sətrində 15 rəqəmli IMEI 1, istəyə görə IMEI 2 və serial yazın. IMEI 1 və IMEI 2 ümumi identifier cədvəlində də yoxlanır; bir sahədəki IMEI digər sahədə təkrarlana bilməz. Alışda təchizatçı və ya satıcı müştəridən yalnız birini seçin. Satışda həmin IMEI-ni yazın. Tarixçə məhsul kartından açılır. Məhsul axtarışı icazəli mağazanın IMEI-sini də tapa bilir.

## Excel

- Yalnız `.xlsx`; bir vərəq; maksimum 1000 məhsul / 3 MB.
- Sütun adları şablondakı kimi və eyni sırada olmalıdır.
- Barkod/SKU sütunlarını Excel-də **mətn** formatında saxlayın; əks halda Excel aparıcı sıfırları və uzun nömrələri dəyişə bilər.
- Preview MySQL-də saxlanır; səhifə yenilənəndə itmir.
- Fayldaxili təkrarlar xəta, bazadakı uyğun məhsullar duplicate kimi göstərilir.
- Təsdiqdə mövcud məhsulu yeniləmək və ya keçmək seçilir. Yeniləmədə miqdar mövcud stoka **əlavə olunur**.
- Import açılış stokudur: kassa və təchizatçı borcu yaratmır. Real alış sənədi əvəzi deyil.
- Xətalı sətirlər Excel kimi yüklənə bilir. Eyni batch ikinci dəfə tətbiq edilmir.
- Export maksimum 5000 sətir; hesabatlarda maksimum 1000 qruplaşdırılmış nəticə. Limit aşılırsa filtri daraldın. Formula injection qarşısı üçün hüceyrələr mətn kimi yazılır.

## Maya dəyəri, borc və mənfəət

- Bütün pul məbləğləri tam **qəpik** kimi saxlanır; qiymətlərdə float hesablanması əsas uçot üçün istifadə olunmur.
- Stok miqdarı tam ədəddir. Kəsr miqdar bu versiyada yoxdur.
- Hər mağaza/məhsul üzrə **çəkili orta maya**. Daxilolmada `(köhnə stok × orta maya + daxil olan miqdar × daxilolma qiyməti) / yeni stok`, nəticə qəpiyə yuvarlaqlaşdırılır.
- Satış sətri həmin anın orta maya dəyərini saxlayır. Sonrakı alışlar keçmiş satış mənfəətini dəyişmir.
- Brüt = xalis satış − satılan məhsulun maya dəyəri.
- Net = brüt − xərclər + digər gəlir + tanınmış servis mənfəəti.
- Servis mənfəəti hazır statusunun tarixində tanınır. Digər əməliyyatlar sənəd tarixi üzrədir.
- Usta maaşı ayrıca ödənilirsə onu Xərc modulunda yazın; servis əmək haqqı müştəriyə hesablanan xidmət gəliridir.
- İkinci əl cihazın fərdi alış qiyməti IMEI kartında saxlanır; satış uçotunda bütün məhsullar üçün seçilmiş çəkili orta metodu tətbiq edilir.
- Alışın tam məbləği dərhal mənfəətdən çıxılmır; satılmamış stok aktiv kimi saxlanır.
- Vergi, ƏDV, fiskal kassa, amortizasiya və rəsmi mühasibat baş kitabı bu paketdə yoxdur. Bu, fiskal proqram təminatı əvəzi deyil.

## İcazələr və təhlükəsizlik

- Super Admin bütün mağazalar; menecer yalnız təyin olunmuş aktiv mağazalar.
- Satış işçisi öz satışları və məhdud əməliyyatlar; servis işçisi özünə aid/təyin olunmuş servislər.
- Rollara əlavə fərdi Bəli/Xeyr/Rol qaydası icazələri. Satış/servis rollarının maliyyə və admin həddi fərdi icazə ilə açılmır.
- PDO prepared statements, HTML escape, CSRF, password_hash/verify, session regeneration, HttpOnly/Secure/SameSite cookie, giriş cəhd limiti.
- Əsas məlumatlar soft-delete edilir; təsdiqlənmiş maliyyə sənədləri silinmir və redaktə olunmur.
- Məhsul şəkilləri yalnız JPG/PNG/WEBP, 2 MB, MIME/ölçü yoxlaması, təsadüfi ad.
- `app`, `config`, `database`, `storage`, `vendor`, `tests`, `docs` HTTP vasitəsilə bağlıdır.
- `.htaccess` qaydaları işləməyən serverdə tətbiqi açıq yayımlamayın.
- Audit tətbiq səviyyəsindədir; DB administratoruna qarşı dəyişdirilməz/tamper-proof jurnal deyil.
- Şəxsi sənəd məlumatlarını yalnız həqiqətən zəruri olduqda yazın. Saxlanma və məxfilik qaydasını biznesiniz üçün ayrıca müəyyən edin.

## Backup və istismar

Super Admin → Backup ilə SQL yükləyin. Faylın sonunda `-- BACKUP COMPLETE` olmalıdır. Faylı ayrıca boş test bazasına bərpa edib yoxlayın. `uploads/` şəkillərini və təhlükəsiz saxlanan konfiqurasiyanı ayrıca ehtiyatlayın. Database backup şəkilləri ehtiva etmir.

Böyük bazada PHP vaxt/yaddaş limiti exportu kəsə bilər. Belə hallarda hosting panelinin phpMyAdmin exportundan istifadə edin. Cron və avtomatik backup xidməti yoxdur.

PHP səhvləri `storage/logs/php.log` faylına yazılır. Onu dövri yoxlayıb təhlükəsiz arxivləyin; shared hosting diskini doldurmayın. Sessiya 60 dəqiqə fəaliyyətsizlikdən sonra bitir. İşdən çıxan əməkdaşı passivləşdirin; hesabı silməyin.

