# 2026.10-clean — yoxlama xülasəsi

**Tarix:** 02.10.2026. **Mühit:** lokal Apache 2.4, PHP 8.4.26, MariaDB 11.8.6, Chromium/Playwright. Bu, GoogieHost-da keçirilmiş test deyil.

| Yoxlama | Nəticə |
|---|---|
| PHP sintaksisi | 692 PHP faylı, vendor daxil — xəta yoxdur |
| Biznes regressiyası | 40/40 assertion: stok, çəkili maya, tarixi maya, qaytarma, transfer, sayım, servis hissələri, borc/qarışıq ödəniş, Excel, paralel son məhsul satışı, kassa, icazə/audit |
| Təmiz quraşdırma/HTTP | 40/40: boş baza, açar, CSRF, yanlış DB parolu, dolu bazanın rəddi, parol təkrarı, ilk admin/mağaza/açılış kassası, təkrar kilid, diaqnostika, giriş, boş modul səhifələri |
| Real brauzer quraşdırması | Alt qovluqda tam quraşdırma və giriş, kassa açmadan seçim; cookie/CSS/private probe; 360/768/1024/1440 px setup — daşma yoxdur |
| Təmiz DB yoxlaması | 0 məhsul, 0 sənəd, 1 seçilmiş admin; seçilən 125.50 açılış kassası 12550 qəpik. Alternativ quraşdırmada kassa sayı 0 |
| Modul HTTP | 63 səhifə — 0 xəta; 9 XLSX export, məhsul API-si, CSRF rəddi və tamamlanmış SQL backup |
| İnterfeys əməliyyatları | 25/25 form/business assertion |
| Responsive/light–dark | 13 səhifə × 5 ölçü × 2 tema = 130; üfüqi body daşması və JS xətası yoxdur |
| HTTP icazə | Satıcı üçün həssas marşrutlar 403; API-də maya gizlidir; məxfi fayllar 403; köhnə install ünvanı kilidli quraşdırıcıya yönlənir |
| Bərpa ssenariləri | 15/15: domen kökü, kök htaccess olmadan birbaşa giriş/health və məxfi qovluqlar, yanlış DB parolu, korlanmış config, çatışmayan router/runtime, yazılmayan sessiya qovluğu, ictimai HTTP POST rəddi |

## Sınaq sərhədləri

- Test database-ləri, config parolları, sessiyalar, test məhsul/şəkilləri, loglar və quraşdırma kilidləri ZIP-də yoxdur.
- Paketdən quraşdırma yeni açar təsdiqi və yeni admin parolu tələb edir. Heç bir universal giriş hesabı yoxdur.
- PHP 8.2/8.3 üzərində ayrıca runtime matrisi, GoogieHost planının real modulları/limitləri, fiziki printer/skaner, böyük real baza/yük və müstəqil təhlükəsizlik auditi bu nəticələrə daxil deyil.
- Host `AllowOverride` qaydalarını tam söndürərsə tətbiq yalnız PHP ilə bütün qeyri-PHP məxfi faylları qoruya bilməz. Browser privacy yoxlaması keçmədən canlı istifadəyə başlamayın.
- Biznes əhatəsi və funksional məhdudiyyətlər `STATUS.md` sənədindədir. Buraxılış qeydsiz-şərtsiz production zəmanəti deyil.
