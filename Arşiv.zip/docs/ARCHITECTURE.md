# Verilənlər bazası və əməliyyat arxitekturası

## İcra modeli

Apache → `index.php` → `app/runtime.php` (erkən yoxlama) → `app/router.php` → sessiya/auth → permission/store scope → validation → `Business` transaction xidməti → PDO → InnoDB.

HTML PHP tərəfindən render edilir. Yalnız POS məhsul axtarışı JSON endpoint vasitəsilə əlavə sorğu göndərir. Chart.js real SQL aqreqatlarını HTML data atributlarından oxuyur. Brauzerin localStorage yaddaşı uçot mənbəyi deyil; bütün biznes məlumatları MySQL-dədir. Heç bir background worker, cron, Redis və WebSocket tələb olunmur.

## Normalizə edilmiş əlaqələr

```text
roles ──< users ──< store_users >── stores
  └──< role_permissions >── permissions ──< user_permissions >── users

categories (parent_id → categories)
brands ──< products >── categories
suppliers ──< products (default supplier, optional)
products ──< product_store_stock >── stores
products ──< product_serials ──< serial_identifiers

stores ──< customers / suppliers
stores ──< documents >── users
customers / suppliers ──< documents
expense_categories ──< documents
documents ──< document_items >── products
product_serials ──< document_items
sale documents ──< return documents (reference_id)
sale items ──< return items (reference_item_id)

documents ──< stock_movements >── products / stores
documents ──< cash_transactions >── cash_registers >── stores
users / stores ──< audit_logs
documents ──< operation_keys
stores / users ──< import_batches ──< import_rows
```

Cəmi 27 əsas cədvəl. `settings`, `login_attempts` də bu saydadır. `database.sql` əsas həqiqət mənbəyidir.

### Paylaşılan sənəd modeli

`documents.type`: `sale`, `purchase`, `return`, `expense`, `income`, `transfer`, `count`, `service`.

Bu model sifarişdə ayrı adlarla göstərilən satış/alış/servis/transfer/sayım cədvəllərinin funksiyasını vahid header + lines + ledger quruluşu ilə verir. Bu cədvəllər saxta proxy və ya yalnız görünüş deyil: hər əməliyyat öz `type`, `status`, `store_id`, `user_id`, əlaqəli tərəf, maya və pul məbləği ilə saxlanır. Beləliklə bütün modullar eyni ledger məntiqini bölüşür.

### Əsas qaydalar

- Məbləğ: signed BIGINT qəpik; mənfi məbləğ kassa çıxışında, mənfi delta stok çıxışında.
- Miqdar: INT. `product_store_stock.qty >= 0` CHECK və tətbiq səviyyəsi yoxlaması.
- Tarix: `DATETIME`, PHP `Asia/Baku`, DB connection `+04:00`.
- Charset/collation: hər cədvəldə explicit UTF8MB4/unicode_ci.
- SKU/barkod ayrıca unique, IMEI1/IMEI2/serial ümumi `serial_identifiers.identifier` unique.
- `document_items.unit_cost` əməliyyat anının dəyişməz maya snapshotudur.
- `documents.total` və `cost_total` sənəd yekunlarıdır; dashboard və hesabatlar onlardan aqreqasiya edilir. Ayrı, sinxronizasiyası pozula bilən işçi statistika cədvəli yoxdur.
- Satış geri qaytarılarkən orijinal `total` dəyişmir; `return.reference_id` üzrə yekun çıxılır. Geri verilmiş pul ilkin satışın `paid` məbləğindən çıxılır; ayrıca mənfi kassa qeydi return sənədinə bağlanır.
- Ödəniş tarixçəsi `cash_transactions` cədvəlindədir; kart/bank da eyni ledger-də fərqli `method` ilə saxlanır.

## Transaction sərhədləri

### Satış / alış

1. Mağaza icazəsi yoxlanır.
2. `beginTransaction()`.
3. Mağaza sətri `FOR UPDATE` ilə kilidlənir.
4. İdempotency açarı yoxlanır.
5. Məhsul/stok sətirləri kilidlənir; mövcud aktiv məhsul və stok yoxlanır.
6. Sənəd, sətirlər, IMEI statusu yaradılır/dəyişir.
7. Stok, maya və `stock_movements` dəyişir.
8. Kassa sessiyası/ödənişlər yoxlanır və yazılır.
9. Yekun məbləğ və borc qaydaları yoxlanır.
10. Audit yazılır, commit edilir.

İstənilən istisnada rollback bütün dəyişiklikləri geri qaytarır. Tamamlanmış satış sənədi üçün müştəriyə mesaj yalnız commitdən sonra göstərilir.

### Paralel satış qorunması

Bütün stok/kassa yazan biznes xidmətləri eyni mağaza sətrini kilidləyir. Eyni mağazada maliyyə yazmaları qısa müddət ardıcıl icra olunur. Transfer iki mağazanı ID sırası ilə kilidləyir. Bu, kiçik/orta shared-hosting iş yükündə sadə və sabit yanaşmadır; yüksək ötürmə qabiliyyəti üçün incə kilidləmə/retry strategiyası ayrıca tələb olunur.

Stok bir olduqda iki PHP prosesinin eyni məhsulu satması test edilib: biri commit, digəri stok çatışmazlığı səbəbilə rollback.

İdempotency: sənəd yaratma açarı `documents.idempotency_key`; qaytarma açarı da unique; ödəniş və servis hissəsi POST açarları `operation_keys`. Təkrar transfer qəbulu, sayım təsdiqi və kassa bağlanışı status əsasında ikinci dəfə tətbiq edilmir.

### Transfer

Göndərmə source stoku azaldır və status `sent` olur. Maya snapshotı sətirdə saxlanır. Qəbul target stokuna həmin maya ilə daxil edir, orta mayanı yeniləyir və status `received` olur. Ləğv source stokunu bərpa edir. Serial varsa `stock → transit → stock` keçidi mağaza ilə birlikdə saxlanır.

### Sayım

Draftda sistem miqdarı və faktiki say saxlanır. Təsdiqdə cari qalıq ilkin snapshotla eyni olmalıdır. Əks halda köhnə fiziki sayla yeni stoku əvəz etməmək üçün əməliyyat rədd edilir.

### Servis

Hər hissə istifadəsi transaction-da stok çıxışı və sətir yaradır. Status keçidləri allowlist vasitəsilə məhdudlaşdırılıb. Hazır mərhələsində əmək haqqı, yekun məbləğ və `recognized_at` yazılır. Sifarişin tarixi ilə gəlirin tanınma tarixi ayrıdır. Ödənişsiz erkən ləğv bütün hissələri geri qaytarır.

## Authorization

- `allowed()` rol + fərdi override + rolun maksimum hüquq həddini tətbiq edir.
- `assert_store()` aktiv mağazaya membership-i yoxlayır.
- `scoped_doc()` sənədin mağazasını, növ icazəsini və sales/service rollarında sahiblik/usta təyinatını yoxlayır.
- Transfer qəbulunda target mağaza, ləğvdə source mağaza ayrıca yoxlanır.
- Menyu gizlətmə tək qoruma deyil; route və biznes xidmətlərində backend yoxlamaları var.
- Export da eyni permission/scope prinsiplərindən istifadə edir. Satış işçisinin API məhsul nəticəsində alış qiyməti yoxdur.

## Performance və hosting

- Əsas siyahılar limit/offset ilə 25/50/100 səhifələnir.
- POS axtarışı maksimum 30 məhsul qaytarır.
- Dashboard məbləğləri aggregate SQL ilə alınır; bütün sənədlər PHP-yə yüklənmir.
- Şəkillər və Composer kitabxanası lokal fayldır; uçot məlumatı filesystem-də saxlanmır.
- Excel import payload/preview MySQL-dədir; təsdiq zamanı yenidən duplicate yoxlanır.
- Exportlar synchronous-dur və limitlidir. Böyük database-də PHP vaxt limiti nəzərə alınmalıdır.
- SQL backup bir REPEATABLE READ transaction içində hissələrlə oxunur; DDL dəyişiklikləri backup zamanı aparılmamalıdır.

## Deployment etibarlılığı

`.htaccess` qorunması məcburi deploy qəbul şərtidir. Apache testində config, vendor, app, database, logs və setup açar faylı üçün 403 alınır. İstifadəçinin hostingi həmin qaydaları ignor edirsə serverə məlumat daxil etməyin.

Quraşdırıcı MySQL DDL əmrlərini transactional hesab etmir. Uğursuz qurulumdan sonra boş baza tələb edilir. Runtime migrasiya sistemi bu versiyada yoxdur; gələcək schema dəyişiklikləri versiyalı migrasiya kimi ayrıca hazırlanmalıdır.

## 2026.10-clean başlanğıc qatı

- `setup.php` → açar/CSRF → boş DB → admin + mağaza → config/lock.
- `health.php` əsas yoxlamalar üçün database və Composer tələb etmir; açarla read-only DB diaqnostikası ayrıca başladılır.
- Sessiyalar `storage/sessions/` daxilində, alt qovluğa uyğun cookie path ilə saxlanır. İctimai POST üçün HTTPS tələb olunur.
- Query-string marşrutlar rewrite olmadan birbaşa `index.php` ilə işləyir. Məxfi qovluqların öz Apache giriş qaydaları var.
- Core/mühit səhvləri üçün sadə recovery ekranı və məxfi log istinad kodu var. PHP başlamadan yaranan Apache və host xətaları tətbiq tərəfindən tutula bilməz.
