# Əhatə və məhdudiyyətlər — 2026.10-clean

Bu sənəd “79 bəndin hamısı tamamdır” iddiasını əvəz etmir. Aşağıda həqiqətən mövcud olan funksiyalar və ilkin tələbdən fərqlər göstərilir. Menyuda boş gələcək-modul səhifələri yoxdur.

## İşləyən əsas modullar

| Modul | Bu paketdə işləyən hissə |
|---|---|
| Login | Username/parol, hash/verify, sessiya yenilənməsi, CSRF, çıxış, cəhd limiti |
| Rollar/işçilər | 4 rol, fərdi icazə, mağaza təyinatı, endirim limiti, passiv hesab |
| Mağazalar | Limitsiz qeyd, ad/kod/ünvan/telefon/menecer/qeyd, aktiv/passiv |
| Məhsullar | Kart, SKU/barkod unikal, kateqoriya/alt kateqoriya, marka, model/rəng/ölçü/RAM/yaddaş/zəmanət, şəkil, soft-delete/bərpa |
| Stok | Mağaza/məhsul qalıqları, çəkili orta maya, hərəkət jurnalı, aşağı stok |
| Alış | Çoxsətirli sənəd, real qiymət, stok artımı, qarışıq ödəniş, təchizatçı və ya ikinci əl satıcı müştəri borcu |
| Satış/POS | Canlı DB axtarışı, barkod/IMEI, səbət, sətir/səbət endirimi, nağd/kart/bank, borclu satış, serverdə stok və qiymət yoxlaması |
| Qaytarma | Satış sətrinə bağlı miqdar, endirimli məbləğin avtomatik hesabı, stok/kassa/borc/maya əksi |
| Transfer | Göndərmə, qəbul, qəbuldan əvvəl ləğv; qarşı stok yalnız qəbulda artır |
| Sayım | Sistem/faktiki/fərq, təsdiqədək dəyişməz stok, köhnəlmiş sayımın rəddi |
| Kassa | Mağaza üzrə bir açıq kassa, nağd/kart/bank hərəkətləri, açılış/gözlənilən/faktiki/fərq/bağlanış |
| Xərclər/gəlirlər | Xərc kateqoriyası, sənəd, mağaza kassası və mənfəətlə əlaqə |
| CRM | Müştəri/təchizatçı, telefon/ünvan/qeyd, sənəd tarixçəsi, ödənişlər, soft-delete/bərpa |
| Borclar | Satış/alış/servis üzrə qalıq, sənəd üzrə ödəniş, təkrar sorğuya qarşı ödəniş açarı, borc siyahısı |
| IMEI | IMEI1/IMEI2/serial unikal identifier, stok/satış/transfer statusu, alış-satış sənədlərinə əlaqə |
| Servis | Qəbul/status/usta/problem/IMEI/təxmin, real hissə sərfi, əmək haqqı, ödəniş, təhvil, məhdud ləğv |
| Hesabatlar | Gün/ay/il/mağaza/işçi/məhsul/kateqoriya üzrə qruplar; sənəd siyahıları və tarix filtrləri; icazəyə görə maya/brüt/net |
| Dashboard | Faktiki məlumat kartları, dövr/mağaza seçimi, satış və mağaza qrafikləri, son sənədlər və stok |
| Excel | PhpSpreadsheet vendor daxildir; XLSX preview/duplicate/error/skip-update/commit, xəta exportu, əsas modul exportları |
| Çap | Satış/alış/servis/transfer/sayım sənədi, hesabat, A4/thermal CSS; Code 128 etiket |
| Audit | Kritik dəyişikliklər, giriş/çıxış/backup/export qeydləri |
| Backup | PHP/PDO ilə ardıcıl snapshot SQL download, completion marker |
| Ayarlar | Şirkət/sistem adı, telefon/ünvan, qəbz logosu, tətbiq olunan tarix formatı |
| Qurulum | Açarla qorunan wizard, boş DB yoxlaması, standart parolsuz admin, qurulum kilidi |

## İlkin 79 bəndlə tam uyğun olmayan / tamamlanmayan hissələr

1. **Production statusu:** bu versiya qəbul-sınağı paketidir. GoogieHost hesabında yerləşdirilməyib. Real biznes yükü, müstəqil penetration testi, fiziki termal printer və USB skaner ilə test aparılmayıb.
2. **PHP versiyası/extension:** PHP 8.2+ tələb olunur, bütün PHP 8.x versiyaları deyil. PhpSpreadsheet üçün standart ZIP/XML/GD modulları tələb edilir. Host onları vermirsə extension-sız fallback yoxdur.
3. **Database adlandırılması:** ayrıca `sales`, `purchase_items`, `sale_payments`, `service_order_parts` və s. yerinə normalizə edilmiş `documents`, `document_items`, `cash_transactions` işlədilir. Bu, saxta görünüş və ya fərqli datanın təkrarı deyil; eyni biznes sənəd modelinin paylaşılmasıdır. İstənilən cədvəl siyahısının hər adı ayrıca mövcud deyil.
4. **IMEI partiyaları:** eyni məhsul bir sənəddə bir sətirdə olmalıdır. Serial izlənən sətirdə yalnız 1 cihaz qəbul edilir. Eyni modeldən 10 IMEI üçün 10 sənəd lazımdır. Toplu IMEI importu, IMEI sayımı və fərdi cihaz səviyyəsində ayrıca RAM/rəng/vəziyyət/qiymət variant redaktəsi yoxdur; atributlar məhsul kartındadır.
5. **Miqdar/valyuta:** yalnız tam ədəd miqdar və AZN. Valyuta/maya metodu uçot ardıcıllığı üçün kilidlidir. FIFO, kəsr vahid, lot/son istifadə tarixi yoxdur.
6. **Excel:** yalnız XLSX, XLS/CSV importu yoxdur. Import açılış stokudur; alış fakturası, kassa və borc yaratmır. Preview səhifələnir, maksimum 1000 sətir. Xəta exportunda ilkin məlumat JSON sütununda verilir, ayrıca redaktə olunan yenidən-import şablonuna çevrilmir.
7. **POS:** kateqoriya dropdown filtri, checkout-da verilən pul/qaytarılacaq qəpik üçün ayrıca kalkulyator, suspended sale və offline rejim yoxdur. Axtarış/səbət/ödəniş realdır. Qiymət məhsul kartından alınır; sətirdə sərbəst satış qiyməti əvəzinə icazəli endirim işlədilir.
8. **Servis:** hazır olmadan avans qəbul edilmir. Hazır/təhvil statusundan sonra hissə dəyişmə və servis qaytarma əməliyyatı yoxdur. Hissə ləğvdə geri qaytarılır; zədələnmiş hissənin ayrıca utilizasiya uçotu yoxdur. Usta maaşının avtomatik hesablanması yoxdur.
9. **Kassa:** hər mağaza üzrə yalnız bir açıq kassa. Bir mağazada çox terminal/kassir üçün paralel fərdi kassa sessiyaları yoxdur. Quraşdırmada ilk kassa istəyə görə açılır. Sonradan mağaza yaradılarkən kassa avtomatik yaranmır; Kassa modulunda ayrıca açılır. Xərc/gəlir ayrıca işləyir, amma kassalararası pul transferi yoxdur.
10. **Kateqoriyalar:** məhsul yalnız bir kateqoriyaya bağlanır; alt kateqoriya seçilə bilər. Çoxlu kateqoriya əlaqəsi və çoxşəkilli qalereya yoxdur. Xərc kateqoriyaları ilkin siyahıdan seçilir; onları admin panelindən ayrıca idarəetmə ekranı yoxdur.
11. **Hesabatlar:** ayrıca həftə qruplaşdırması yoxdur (bu həftə tarix filtri var). Hər tələb edilən hesabatın ayrıca premium analitik ekranı yoxdur; alış, xərc, kassa, sayım, servis və transfer üçün işləyən sənəd/hərəkət siyahıları istifadə olunur. İkinci əl telefonlar üçün ayrıca konsolidasiya edilmiş mənfəət hesabatı, dashboardda ayrıca xərc/kateqoriya/aylıq/mənfəət qrafiklərinin hamısı yoxdur. Məhsul/ay/kateqoriya və mənfəət qrafikləri uyğun Hesabat səhifələrində mövcuddur; xərc qrafiki yoxdur.
12. **Filtrlər/sıralama:** əsas siyahılar server-side səhifələnir. Hər sütunda sərbəst sort və bütün modullarda eyni səviyyədə kombinə edilən filtr dəsti yoxdur. Müştəri/usta seçim dropdownları 1000, kateqoriya/marka seçimləri 2000 qeydlə məhduddur. IMEI tarixçəsində son 100 qeyd, ödəniş tarixçəsində son 100 qeyd göstərilir. Çox böyük bazalar üçün ayrıca AJAX seçim komponentləri lazımdır.
13. **Demo təmizləmə:** production-da demo data yaradılmır; ona görə “Demo məlumatları sil” düyməsi yoxdur. İnkişaf testləri yalnız ayrıca test database-də fixture yaradır; test runner production ZIP-ə daxil edilmir.
14. **Məlumat bərpası:** məhsul/müştəri/təchizatçı soft-delete və bərpası var. Təsdiqlənmiş maliyyə sənədləri silinmir; alış qaytarma və mühasibat reversal jurnalı ayrıca modul kimi yoxdur. Köhnəlmiş sayım draftının ayrıca ləğv düyməsi yoxdur.
15. **Şəxsi məlumatlar və audit:** forma validation/escape var; bazadakı şəxsi məlumatların tətbiq səviyyəsində şifrələnməsi, 2FA, parol unutma e-poçtu, dəyişdirilməz audit, audit retention paneli yoxdur. İstifadəçini və backup-ları idarə edən şəxs təhlükəsiz saxlama proseduru təyin etməlidir.
16. **Backup:** SQL export yalnız database-i əhatə edir. Şəkillər ayrıca yedəklənir. İnterfeysdə restore/avtomatik cloud backup və limitdən böyük baza üçün resumable streaming job yoxdur.
17. **Satınalma uçotu:** freight/landed cost, valyuta çevrilməsi, alış qaytarma, ƏDV, rəsmi fiskal sənəd və baş kitab yoxdur. Xalis mənfəət əməliyyat mənfəətidir, rəsmi audit olunmuş maliyyə hesabatı deyil.
18. **Genişlənmə:** siniflər və transaction xidmətləri ayrıdır. Hazır public/versioned API, online mağaza, WhatsApp/SMS/mobil tətbiq inteqrasiyası yoxdur; bunlar ilkin istəkdə də gələcək üçün nəzərdə tutulurdu.

## Release qəbul qapısı

Aşağıdakılar tamamlanmadan real biznesin yeganə uçot bazası kimi istifadə etməyin:

- GoogieHost-da PHP modulları, `.htaccess` məxfiliyi, HTTPS/cookie, timeout/upload limitlərinin yoxlanması.
- Faktiki məhsul/IMEI ssenarilərinə uyğun biznes qaydalarının təsdiqi.
- Öz printerinizdə qəbz və etiket ölçülərinin sınağı.
- Ayrı test bazasında gündəlik işçi/admin qəbul sınağı və backup bərpası.
- Mənbə kodunun təhlükəsizlik və maliyyə məntiqi üzrə müstəqil baxışı.
- Yuxarıdakı fərqlərdən biznesinizə lazım olanların tamamlanması.
