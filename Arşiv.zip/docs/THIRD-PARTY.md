# Üçüncü tərəf komponentləri

- Bootstrap 5.3.3 — MIT — https://github.com/twbs/bootstrap
- Chart.js 4.4.8 — MIT — https://github.com/chartjs/Chart.js
- JsBarcode 3.11.6 — MIT — https://github.com/lindell/JsBarcode
- PhpSpreadsheet 5.10.0 — MIT — https://github.com/PHPOffice/PhpSpreadsheet
- PhpSpreadsheet tranzitiv asılılıqları: tam versiyalar `composer.lock`, lisenziyalar `vendor/` qovluğundadır.

Frontend kitabxanaları lokal `assets/` fayllarından işləyir; CDN bağlantısı tələb edilmir. Kitabxana fayllarındakı copyright/lisenziya başlıqlarını silməyin. Yeniləmədən əvvəl Composer audit və regressiya testlərini ayrıca development mühitində aparın; hostingdə Composer işlətmək tələb olunmur.

## UI 2026 əlavələri

- Lucide 0.468.0 — ISC, lokal `assets/lucide.min.js`; lisenziya `assets/licenses/lucide-LICENSE.txt`.
- Inter — SIL Open Font License, lokal 400/500/600/700 şriftləri; lisenziya `assets/licenses/inter-OFL.txt`.
