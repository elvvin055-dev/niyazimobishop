<?php
/** Minimal, database-independent startup and recovery layer. No Composer needed here. */
if (!defined('MOBISHOP_ENTRY') && PHP_SAPI !== 'cli') { http_response_code(403); exit; }
if (!defined('MOBISHOP_ROOT')) { define('MOBISHOP_ROOT', dirname(__DIR__)); }
function mshop_escape($value) { return htmlspecialchars((string)$value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'); }
function mshop_https() {
    if (!empty($_SERVER['HTTPS']) && strtolower($_SERVER['HTTPS']) !== 'off') return true;
    if (isset($_SERVER['SERVER_PORT']) && (int)$_SERVER['SERVER_PORT'] === 443) return true;
    // SSL-terminating shared-hosting/CDN proxies commonly set this header.
    if (isset($_SERVER['HTTP_X_FORWARDED_PROTO']) && strtolower(trim(explode(',', $_SERVER['HTTP_X_FORWARDED_PROTO'])[0])) === 'https') return true;
    return false;
}
function mshop_local() {
    $remote = isset($_SERVER['REMOTE_ADDR']) ? $_SERVER['REMOTE_ADDR'] : '';
    $host = isset($_SERVER['HTTP_HOST']) ? strtolower(explode(':', $_SERVER['HTTP_HOST'])[0]) : '';
    return in_array($remote, array('127.0.0.1','::1'), true) && in_array($host, array('localhost','127.0.0.1','[::1]'), true);
}
function mshop_log($error) {
    $ref = 'MS-' . date('ymd-His') . '-' . substr(hash('sha256', uniqid('', true)), 0, 6);
    $message = $ref . ' ' . (is_object($error) ? get_class($error) . ': ' . $error->getMessage() . ' in ' . $error->getFile() . ':' . $error->getLine() : (string)$error);
    // A PHP guard also protects logs if an Apache access file is temporarily disabled.
    $path = MOBISHOP_ROOT . '/storage/logs/application.php';
    if (!is_file($path)) @file_put_contents($path, "<?php http_response_code(403); exit; ?>\n", LOCK_EX);
    @error_log($message . "\n", 3, $path);
    return $ref;
}
function mshop_safety_net() {
    ini_set('display_errors', '0');
    ini_set('log_errors', '1');
    $log = MOBISHOP_ROOT . '/storage/logs/php-error.php';
    if (!is_file($log)) @file_put_contents($log, "<?php http_response_code(403); exit; ?>\n", LOCK_EX);
    ini_set('error_log', $log);
    $GLOBALS['mshop_reserve'] = str_repeat('x', 262144);
    $GLOBALS['mshop_handled'] = false;
    $GLOBALS['mshop_ob_start'] = ob_get_level();
    ob_start();
    register_shutdown_function(function () {
        $error = error_get_last();
        if (!$error || !in_array($error['type'], array(E_ERROR,E_PARSE,E_CORE_ERROR,E_COMPILE_ERROR,E_USER_ERROR), true) || !empty($GLOBALS['mshop_handled'])) return;
        $GLOBALS['mshop_reserve'] = null;
        $GLOBALS['mshop_handled'] = true;
        $reference = mshop_log('Fatal ' . $error['message'] . ' at ' . $error['file'] . ':' . $error['line']);
        mshop_recovery('Bir problem baş verdi', 'Tətbiq sorğunu tamamlaya bilmədi. Hosting yoxlamasını açın; PHP versiyası, fayllar və yaddaş limitini yoxlayın.', array('Xəta kodu: ' . $reference), 500);
    });
}
function mshop_recovery($title, $description, $items = array(), $status = 503) {
    $GLOBALS['mshop_handled'] = true;
    $base = isset($GLOBALS['mshop_ob_start']) ? $GLOBALS['mshop_ob_start'] : 0;
    while (ob_get_level() > $base) @ob_end_clean();
    if (!headers_sent()) {
        http_response_code($status);
        header('Content-Type: text/html; charset=utf-8');
        header('Cache-Control: no-store');
        header('X-Content-Type-Options: nosniff');
    }
    $isApi = isset($_GET['r']) && $_GET['r'] === 'api_products';
    if ($isApi) {
        if (!headers_sent()) header('Content-Type: application/json; charset=utf-8');
        echo json_encode(array('error'=>$title,'message'=>$description));
        exit;
    }
    echo '<!doctype html><html lang="az"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>MobiShop Niyazi · Yoxlama</title><style>';
    echo 'body{margin:0;background:#f4f7fc;color:#14213b;font:15px system-ui,-apple-system,Segoe UI,sans-serif;line-height:1.7}.shell{max-width:670px;margin:10vh auto;padding:24px}.brand{font-weight:700;letter-spacing:-1px;font-size:26px;color:#102444}.brand small{display:block;font-size:10px;letter-spacing:3px;color:#64748b}article{background:white;border:1px solid #e2e8f0;border-radius:18px;padding:32px;margin-top:28px;box-shadow:0 12px 50px #0b122006}.code{display:inline-block;border:1px solid #dbe7ff;color:#2563eb;background:#eff6ff;border-radius:8px;padding:5px 10px;font-size:11px}h1{font-size:25px;letter-spacing:-.6px;line-height:1.3}p,li{color:#64748b;font-size:13px}.actions{display:flex;gap:10px;flex-wrap:wrap;margin-top:25px}a{display:inline-block;border:1px solid #dbe3ee;border-radius:8px;padding:11px 16px;color:#2563eb;text-decoration:none;font-size:12px}.primary{background:#2563eb;color:#fff;border-color:#2563eb}.foot{font-size:11px;color:#94a3b8;margin-top:22px}';
    echo '</style></head><body><main class="shell"><div class="brand">MobiShop<small>NİYAZİ · RETAIL WORKSPACE</small></div><article><span class="code">HOSTING / TƏTBİQ YOXLAMASI</span><h1>' . mshop_escape($title) . '</h1><p>' . mshop_escape($description) . '</p>';
    if ($items) { echo '<ul>'; foreach ($items as $item) echo '<li>' . mshop_escape($item) . '</li>'; echo '</ul>'; }
    echo '<div class="actions"><a class="primary" href="health.php">Hosting yoxlamasını aç</a><a href="index.php">Yenidən cəhd et</a></div></article><div class="foot">Database və konfiqurasiya avtomatik silinmir. SQL kodu və parollar bu səhifədə göstərilmir.</div></main></body></html>';
    exit;
}
function mshop_failure($error) {
    $reference = mshop_log($error);
    if ($error instanceof PDOException) {
        mshop_recovery('Database bağlantısını yoxlayın', 'MySQL sorğusu yerinə yetirilə bilmədi. Database host/ad/istifadəçi məlumatlarını, istifadəçi icazələrini və quraşdırmanın tamamlanmasını yoxlayın.', array('Quraşdırılmış saytda config/config.php məlumatlarını hosting panelində yoxlayın.','Xəta kodu: ' . $reference), 503);
    }
    mshop_recovery('Bir problem baş verdi', 'Sorğu tamamlana bilmədi. Hosting yoxlamasını açın. Problem davam edərsə aşağıdakı kodu texniki dəstəyə bildirin.', array('Xəta kodu: ' . $reference), 500);
}
function mshop_checks() {
    $checks = array();
    $checks[] = array('label'=>'PHP 8.2 və daha yeni','ok'=>PHP_VERSION_ID >= 80200,'detail'=>'Aktiv versiya: ' . PHP_VERSION,'required'=>true);
    $checks[] = array('label'=>'64-bit PHP','ok'=>PHP_INT_SIZE === 8,'detail'=>'Excel kitabxanası üçün tələb olunur.','required'=>true);
    foreach (array('pdo_mysql','mbstring','session','json','ctype','dom','xml','xmlreader','xmlwriter','zip','fileinfo','gd','iconv','simplexml') as $extension) {
        $checks[] = array('label'=>'PHP: ' . $extension,'ok'=>extension_loaded($extension),'detail'=>extension_loaded($extension)?'Aktivdir':'Hosting PHP Extensions bölməsində aktiv edin.','required'=>true);
    }
    foreach (array('app/bootstrap.php','app/router.php','app/Business.php','app/Catalog.php','app/Excel.php','app/view.php','assets/app.css','assets/app.js','assets/lucide.min.js','database/database.sql','vendor/autoload.php','vendor/phpoffice/phpspreadsheet/src/PhpSpreadsheet/Spreadsheet.php','vendor/composer/platform_check.php') as $file) {
        $checks[] = array('label'=>$file,'ok'=>is_readable(MOBISHOP_ROOT . '/' . $file),'detail'=>is_readable(MOBISHOP_ROOT . '/' . $file)?'Fayl mövcuddur':'ZIP tam açılmayıb. Bu faylı yenidən yükləyin.','required'=>true);
    }
    foreach (array('config','storage','storage/logs','storage/sessions','uploads') as $folder) {
        $checks[] = array('label'=>$folder . ' · yazma icazəsi','ok'=>is_dir(MOBISHOP_ROOT . '/' . $folder) && is_writable(MOBISHOP_ROOT . '/' . $folder),'detail'=>'Hosting sahiblik və icazələrini yoxlayın; əvvəlcə 755 istifadə edin. 777 açıq icazə verməyin.','required'=>true);
    }
    $memory = trim(ini_get('memory_limit'));
    $bytes = mshop_ini_bytes($memory);
    $checks[] = array('label'=>'PHP yaddaş limiti','ok'=>$memory === '-1' || $bytes >= 128*1024*1024,'detail'=>$memory . ' · Excel üçün 256 MB tövsiyə olunur.','required'=>false);
    $upload=mshop_ini_bytes(ini_get('upload_max_filesize'));$post=mshop_ini_bytes(ini_get('post_max_size'));
    $checks[] = array('label'=>'Fayl yükləmə limitləri','ok'=>$upload>=3*1024*1024 && $post>=4*1024*1024,'detail'=>'upload_max_filesize=' . ini_get('upload_max_filesize') . ', post_max_size=' . ini_get('post_max_size') . '. Kiçik fayllar daha aşağı limitdə də işləyə bilər.','required'=>false);
    $checks[] = array('label'=>'HTTPS bağlantısı','ok'=>mshop_https()||mshop_local(),'detail'=>mshop_local()?'Yerli test mühiti; production HTTPS olmalıdır.':'Domenin SSL sertifikatını hosting panelində aktiv edin.','required'=>true);
    return $checks;
}
function mshop_ini_bytes($value) {
    if ($value === '-1') return PHP_INT_MAX;
    $last = strtolower(substr(trim($value), -1));$number=(float)$value;
    if ($last === 'g') $number*=1024*1024*1024;
    elseif ($last === 'm') $number*=1024*1024;
    elseif ($last === 'k') $number*=1024;
    return (int)$number;
}
function mshop_require_runtime() {
    if (PHP_VERSION_ID < 80200 || PHP_INT_SIZE !== 8) {
        mshop_recovery('PHP versiyası uyğun deyil', 'Hosting panelində bu domen üçün PHP 8.2, 8.3 və ya 8.4 (64-bit) seçin. Aşağı versiyada tətbiq yüklənmir; bu, database xətası deyil.', array('Hazırkı versiya: ' . PHP_VERSION), 503);
    }
    $missing=array();
    foreach (array('pdo_mysql','mbstring','session','json','fileinfo') as $ext) if(!extension_loaded($ext))$missing[]='PHP modulu: '.$ext;
    foreach (array('app/bootstrap.php','app/router.php','app/helpers.php','app/auth.php','app/view.php','app/Business.php') as $file) if(!is_file(MOBISHOP_ROOT.'/'.$file))$missing[]=$file;
    if($missing)mshop_recovery('Hosting və ya paket yoxlaması tələb olunur','Aşağıdakı komponentlər tapılmadı. Tam ZIP paketini açın və tələb olunan PHP modullarını aktiv edin.',$missing,503);
}
