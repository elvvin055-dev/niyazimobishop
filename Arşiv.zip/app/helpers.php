<?php
declare(strict_types=1);
if (!defined('MOBISHOP_ENTRY') && PHP_SAPI !== 'cli') { http_response_code(403); exit; }

class UserError extends RuntimeException {}
function db(): PDO {
    global $config;
    static $pdo;
    if (!$pdo) {
        $pdo = new PDO('mysql:host='.$config['db_host'].';port='.(int)($config['db_port']??3306).';dbname='.$config['db_name'].';charset=utf8mb4', $config['db_user'], $config['db_pass'], [PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC, PDO::ATTR_EMULATE_PREPARES=>false]);
        $pdo->exec("SET time_zone = '+04:00'");
        $pdo->exec("SET SESSION sql_mode = 'STRICT_TRANS_TABLES,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION'");
    }
    return $pdo;
}
function q(string $sql, array $args=[]): PDOStatement { $s=db()->prepare($sql); $s->execute($args); return $s; }
function one(string $sql,array $args=[]): ?array { return q($sql,$args)->fetch() ?: null; }
function all(string $sql,array $args=[]): array { return q($sql,$args)->fetchAll(); }
function val(string $sql,array $args=[]): mixed { return q($sql,$args)->fetchColumn(); }
function insert(string $table,array $data): int {
    // Table/column identifiers ONLY come from application constants, never request input.
    $cols=array_keys($data);
    q('INSERT INTO `'.$table.'` (`'.implode('`,`',$cols).'`) VALUES ('.implode(',',array_fill(0,count($cols),'?')).')',array_values($data));
    return (int)db()->lastInsertId();
}
function update(string $table,array $data,int $id): void {
    q('UPDATE `'.$table.'` SET '.implode(',',array_map(fn($k)=>'`'.$k.'`=?',array_keys($data))).' WHERE id=?',[...array_values($data),$id]);
}
function atomic(callable $fn): mixed {
    db()->beginTransaction();
    try { $r=$fn(); db()->commit(); return $r; } catch(Throwable $e) { if(db()->inTransaction()) db()->rollBack(); throw $e; }
}
function e(mixed $s): string { return htmlspecialchars((string)$s, ENT_QUOTES|ENT_SUBSTITUTE,'UTF-8'); }
function money(mixed $n): string { return number_format((int)$n/100,2,'.',' ').' AZN'; }
function cents(mixed $s): int {
    $s=str_replace(',','.',trim((string)$s));
    if(!preg_match('/^\d{1,9}(?:\.\d{1,2})?$/D',$s)) throw new UserError('Məbləği düzgün yazın (məsələn 150.00).');
    [$a,$b]=array_pad(explode('.',$s),2,''); return (int)$a*100+(int)str_pad($b,2,'0');
}
function integer(mixed $n,int $min=0,int $max=1000000): int {
    if(!preg_match('/^\d+$/D',(string)$n) || (int)$n<$min || (int)$n>$max) throw new UserError('Miqdar düzgün deyil.'); return (int)$n;
}
function text(mixed $s,int $max=255,bool $required=false): string {
    $s=trim((string)$s); if(($required && $s==='') || mb_strlen($s)>$max) throw new UserError('Mətn sahəsi boşdur və ya çox uzundur.'); return $s;
}
function csrf(): string { return $_SESSION['csrf'] ??= bin2hex(random_bytes(32)); }
function csrf_field(): string { return '<input type="hidden" name="csrf" value="'.e(csrf()).'">'; }
function check_csrf(): void { if(!hash_equals(csrf(),(string)($_POST['csrf']??''))) throw new UserError('Sessiya yoxlaması uğursuzdur. Səhifəni yeniləyin.'); }
function token(): string { return bin2hex(random_bytes(32)); }
function go(string $route='dashboard',array $params=[]): never { header('Location: index.php?'.http_build_query(['r'=>$route]+$params)); exit; }
function flash(string $s,string $type='success'): void { $_SESSION['flash']=[$s,$type]; }
function audit(string $action,?int $id=null,?int $store=null,array $details=[]): void {
    insert('audit_logs',['user_id'=>user()['id']??null,'store_id'=>$store,'action'=>$action,'entity_id'=>$id,'details'=>json_encode($details,JSON_UNESCAPED_UNICODE),'ip'=>$_SERVER['REMOTE_ADDR']??'CLI']);
}
function settings(): array { return q('SELECT `key`, value FROM settings')->fetchAll(PDO::FETCH_KEY_PAIR); }
function date_range(): array {
    $preset=$_GET['period']??((($_GET['r']??'dashboard')==='dashboard')?'today':'month'); $today=date('Y-m-d');
    [$from,$to]=match($preset){'today'=>[$today,$today],'yesterday'=>[date('Y-m-d',strtotime('-1 day')),date('Y-m-d',strtotime('-1 day'))],'week'=>[date('Y-m-d',strtotime('monday this week')),$today],'year'=>[date('Y-01-01'),$today],'custom'=>[$_GET['from']??$today,$_GET['to']??$today],default=>[date('Y-m-01'),$today]};
    foreach([$from,$to] as $d) if(!is_string($d)||!preg_match('/^\d{4}-\d{2}-\d{2}$/D',$d)||date('Y-m-d',strtotime($d))!==$d) throw new UserError('Tarix düzgün deyil.');
    if($from>$to) throw new UserError('Tarix aralığı düzgün deyil.');
    return [$from.' 00:00:00',date('Y-m-d',strtotime($to.' +1 day')).' 00:00:00'];
}
function upload_image(string $field): ?string {
    $f=$_FILES[$field]??null; if(!$f || $f['error']===UPLOAD_ERR_NO_FILE) return null;
    if($f['error']!==UPLOAD_ERR_OK || $f['size']>2*1024*1024) throw new UserError('Şəkil maksimum 2 MB olmalıdır.');
    $info=getimagesize($f['tmp_name']); $map=['image/jpeg'=>'jpg','image/png'=>'png','image/webp'=>'webp'];
    if(!$info || !isset($map[$info['mime']]) || $info[0]>8000 || $info[1]>8000) throw new UserError('Yalnız JPG, PNG, WEBP şəkil qəbul edilir.');
    $name=bin2hex(random_bytes(20)).'.'.$map[$info['mime']];
    if(!move_uploaded_file($f['tmp_name'],dirname(__DIR__).'/uploads/'.$name)) throw new UserError('Şəkil saxlanmadı. Upload icazəsini yoxlayın.');
    return $name;
}
function page_size(): int { $n=(int)($_GET['size']??25); return in_array($n,[25,50,100],true)?$n:25; }
function page_num(): int { return max(1,min(100000,(int)($_GET['page']??1))); }
function error_message(Throwable $e): string {
    if($e instanceof UserError) return $e->getMessage();
    $reference=mshop_log($e);
    if($e instanceof PDOException && $e->getCode()==='23000') return 'Məlumat təkrarlanır və ya əlaqəli qeyd mövcud deyil (SKU, barkod, IMEI yoxlayın).';
    return 'Əməliyyat tamamlanmadı. Nəticəni yoxlamadan sorğunu təkrarlamayın. Xəta kodu: '.$reference;
}

function dt(mixed $value): string { if(!$value)return '—'; static $format; $format??=settings()['date_format']??'d.m.Y'; return date($format.(strlen((string)$value)>10?' H:i':''),strtotime((string)$value)); }
