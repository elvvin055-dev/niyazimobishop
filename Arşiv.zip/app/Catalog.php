<?php
declare(strict_types=1);
if (!defined('MOBISHOP_ENTRY') && PHP_SAPI !== 'cli') { http_response_code(403); exit; }

final class Catalog {
    public static function definitions(): array { return [
        'stores'=>['title'=>'Mağazalar','permission'=>'stores','fields'=>['name'=>['Mağaza adı','text',true],'code'=>['Kod','text',true],'address'=>['Ünvan','text'],'phone'=>['Telefon','text'],'manager_id'=>['Menecer','users'],'active'=>['Aktiv','bool'],'note'=>['Qeyd','textarea']]],
        'categories'=>['title'=>'Kateqoriyalar','permission'=>'categories','fields'=>['name'=>['Ad','text',true],'parent_id'=>['Üst kateqoriya','categories']]],
        'brands'=>['title'=>'Markalar','permission'=>'categories','fields'=>['name'=>['Ad','text',true]]],
        'customers'=>['title'=>'Müştərilər','permission'=>'customers','fields'=>['name'=>['Ad','text',true],'phone'=>['Telefon','text'],'address'=>['Ünvan','text'],'identity_note'=>['Sənəd məlumatı (zəruri olduqda)','text'],'note'=>['Qeyd','textarea']]],
        'suppliers'=>['title'=>'Təchizatçılar','permission'=>'suppliers','fields'=>['name'=>['Ad','text',true],'company'=>['Şirkət','text'],'phone'=>['Telefon','text'],'address'=>['Ünvan','text'],'note'=>['Qeyd','textarea']]],
        'products'=>['title'=>'Məhsullar','permission'=>'products','fields'=>['name'=>['Məhsul adı','text',true],'sku'=>['SKU','text',true],'barcode'=>['Barkod','text'],'category_id'=>['Kateqoriya / alt kateqoriya','categories'],'brand_id'=>['Marka','brands'],'model'=>['Model','text'],'color'=>['Rəng','text'],'size'=>['Ölçü','text'],'ram'=>['RAM','text'],'memory'=>['Yaddaş','text'],'condition_note'=>['Vəziyyət','text'],'warranty'=>['Zəmanət','text'],'is_serial'=>['IMEI ilə izlənilir','bool'],'is_used'=>['İkinci əl','bool'],'buy_price'=>['İlkin alış qiyməti','money'],'sell_price'=>['Satış qiyməti','money'],'min_stock'=>['Minimum stok','int'],'max_stock'=>['Maksimum stok','int'],'supplier_id'=>['Təchizatçı','suppliers'],'image'=>['Şəkil (2 MB)','file'],'active'=>['Aktiv','bool'],'note'=>['Qeyd','textarea']]],
    ]; }
    public static function def(string $table): array { $d=self::definitions()[$table]??null; if(!$d) throw new UserError('Bölmə tapılmadı.');require_perm($d['permission']);return $d; }
    public static function options(string $kind): array {
        if(in_array($kind,['categories','brands'],true)) return all("SELECT id,name FROM $kind ORDER BY name LIMIT 2000");
        if($kind==='suppliers') return all('SELECT id,name FROM suppliers WHERE store_id=? AND deleted_at IS NULL ORDER BY name LIMIT 1000',[store_id()]);
        if($kind==='users') return all('SELECT id,name FROM users WHERE active=1 ORDER BY name LIMIT 1000');
        return [];
    }
    public static function record(string $table,int $id): ?array {
        self::def($table);$r=one("SELECT * FROM $table WHERE id=?",[$id]);
        if($r && isset($r['store_id'])) assert_store((int)$r['store_id']); return $r;
    }
    public static function save(string $table,array $in): int {
        $def=self::def($table); if($table==='products') require_perm('product_edit');
        $id=(int)($in['id']??0);$old=$id?self::record($table,$id):null;if($id&&!$old) throw new UserError('Qeyd tapılmadı.');
        $data=[];
        foreach($def['fields'] as $key=>[$label,$type]) {
            if($key==='buy_price'&&!allowed('profit')) continue;
            $v=$in[$key]??'';
            $data[$key]=match($type){'money'=>cents($v?:'0'),'int'=>integer($v?:'0'),'bool'=>isset($in[$key])?1:0,'categories','brands','suppliers','users'=>$v?integer($v,1):null,'file'=>upload_image($key),default=>text($v,$type==='textarea'?5000:($key==='name'?160:($key==='sku'||$key==='barcode'?80:255)),($def['fields'][$key][2]??false))};
            if($type==='file'&&!$data[$key]) unset($data[$key]);
        }
        if($table==='products') {
            $data['barcode']=$data['barcode']?:null;
            if(($data['max_stock']??0)>0 && $data['max_stock']<$data['min_stock']) throw new UserError('Maksimum stok minimumdan kiçikdir.');
            if($data['supplier_id']) { $sup=one('SELECT store_id FROM suppliers WHERE id=?',[$data['supplier_id']]);if(!$sup)throw new UserError('Təchizatçı tapılmadı.');assert_store((int)$sup['store_id']); }
        }
        if($table==='categories'&&$id&&$data['parent_id']) {
            $parent=$data['parent_id'];$visited=[$id];
            while($parent){if(in_array($parent,$visited,true))throw new UserError('Kateqoriya dövrü yarana bilməz.');$visited[]=$parent;$parent=(int)val('SELECT parent_id FROM categories WHERE id=?',[$parent]);}
        }
        if(in_array($table,['customers','suppliers'],true)&&!$id) { $data['store_id']=store_id();assert_store(store_id()); }
        return atomic(function()use($table,$id,$old,$data){
            if($table==='products'&&$id) {
                $p=one('SELECT * FROM products WHERE id=? FOR UPDATE',[$id]);
                if((int)$p['is_serial']!==(int)$data['is_serial'] && (int)val('SELECT COUNT(*) FROM stock_movements WHERE product_id=?',[$id])>0) throw new UserError('Hərəkəti olan məhsulun IMEI izləmə rejimi dəyişdirilmir.');
            }
            if($id) update($table,$data,$id); else $id=insert($table,$data);
            audit($table.' saxlanıldı',$id,in_array($table,['customers','suppliers'],true)?store_id():null);return $id;
        });
    }
    public static function toggleDelete(string $table,int $id): void {
        if(!in_array($table,['products','customers','suppliers'],true)) throw new UserError('Bu məlumat silinmir; passivləşdirin.');
        self::def($table);if($table==='products')require_perm('product_delete');$r=self::record($table,$id);if(!$r)throw new UserError('Tapılmadı.');
        atomic(function()use($table,$id,$r){ update($table,['deleted_at'=>$r['deleted_at']?null:date('Y-m-d H:i:s')],$id);audit($r['deleted_at']?'Bərpa: '.$table:'Soft delete: '.$table,$id,$r['store_id']??null); });
    }
    public static function saveUser(array $in): int {
        require_perm('users');$id=(int)($in['id']??0);$role=integer($in['role_id']??0,1,4);$active=isset($in['active'])?1:0;
        if($id===(int)user()['id']&&($role!==1||!$active))throw new UserError('Öz admin hesabınızı passivləşdirə və rolunu dəyişə bilməzsiniz.');
        $limit=cents($in['discount_limit']??'0');if($limit>10000)throw new UserError('Endirim limiti 0–100% olmalıdır.');
        $data=['name'=>text($in['name']??'',120,true),'username'=>text($in['username']??'',80,true),'role_id'=>$role,'active'=>$active,'discount_limit'=>$limit/100];
        $password=(string)($in['password']??'');if(!$id||$password!==''){if(strlen($password)<12||strlen($password)>72)throw new UserError('Parol 12–72 simvol olmalıdır.');$data['password_hash']=password_hash($password,PASSWORD_DEFAULT);}
        return atomic(function()use($id,$data,$in){
            if($id){if(!one('SELECT id FROM users WHERE id=? FOR UPDATE',[$id]))throw new UserError('İşçi tapılmadı.');update('users',$data,$id);}else $id=insert('users',$data);
            q('DELETE FROM store_users WHERE user_id=?',[$id]);
            foreach(array_unique($in['stores']??[]) as $s)insert('store_users',['user_id'=>$id,'store_id'=>integer($s,1)]);
            q('DELETE FROM user_permissions WHERE user_id=?',[$id]);
            $valid=array_column(all('SELECT code FROM permissions'),'code');
            foreach($in['permissions']??[] as $p=>$v) if(in_array($p,$valid,true)&&in_array($v,['0','1'],true))insert('user_permissions',['user_id'=>$id,'permission'=>$p,'allowed'=>(int)$v]);
            audit('İşçi / icazə saxlanıldı',$id);return $id;
        });
    }
}
