<?php
declare(strict_types=1);
if (!defined('MOBISHOP_ENTRY') && PHP_SAPI !== 'cli') { http_response_code(403); exit; }

require __DIR__.'/bootstrap.php';
if(empty($config['installed'])){header('Location: setup.php');exit;}
require __DIR__.'/Catalog.php';require __DIR__.'/view.php';require __DIR__.'/queries.php';
$route=(string)($_GET['r']??'dashboard');
try {
 if($_SERVER['REQUEST_METHOD']==='POST'){
    check_csrf();$action=$_POST['action']??'';
    if($action==='login'){
        if(login(text($_POST['username']??'',80,true),(string)($_POST['password']??'')))go();
        throw new UserError('İstifadəçi adı və ya parol səhvdir.');
    }
    if(!user())go('login');
    switch($action){
        case 'logout':audit('Çıxış');$_SESSION=[];session_destroy();go('login');
        case 'switch_store':$s=integer($_POST['store_id']??0,1);assert_store($s);$_SESSION['store_id']=$s;go();
        case 'catalog_save':$table=(string)($_POST['table']??'');$id=Catalog::save($table,$_POST);flash('Məlumat uğurla saxlanıldı.');go('catalog',['table'=>$table]);
        case 'catalog_delete':$table=(string)($_POST['table']??'');Catalog::toggleDelete($table,integer($_POST['id'],1));flash('Məlumatın statusu dəyişdirildi.');go('catalog',['table'=>$table]);
        case 'user_save':Catalog::saveUser($_POST);flash('İşçi və icazələr saxlanıldı.');go('users');
        case 'document_create':$_POST['store_id']=store_id();$id=Business::create((string)$_POST['type'],$_POST);flash('Əməliyyat uğurla tamamlandı.');go('document',['id'=>$id]);
        case 'transfer_receive':case 'transfer_cancel':Business::receiveTransfer(integer($_POST['id'],1),$action==='transfer_cancel');break;
        case 'count_approve':Business::approveCount(integer($_POST['id'],1));break;
        case 'payment':Business::payment(integer($_POST['id'],1),$_POST);break;
        case 'return':$id=Business::returnSale(integer($_POST['id'],1),$_POST);flash('Qaytarma qeydə alındı.');go('document',['id'=>$id]);
        case 'service_part':Business::servicePart(integer($_POST['id'],1),$_POST);break;
        case 'service_status':Business::serviceStatus(integer($_POST['id'],1),$_POST);break;
        case 'cash_open':Business::cashOpen(store_id(),cents($_POST['amount']??'0'));flash('Kassa açıldı.');go('cash');
        case 'cash_close':Business::cashClose(store_id(),cents($_POST['amount']??'0'));flash('Kassa bağlandı.');go('cash');
        case 'settings_save':require_perm('settings');atomic(function(){foreach(['company','system_name','phone','address','date_format']as $key){$v=text($_POST[$key]??'',255);if($key==='date_format'&&!in_array($v,['d.m.Y','Y-m-d','d/m/Y'],true))throw new UserError('Tarix formatı düzgün deyil.');q('UPDATE settings SET value=? WHERE `key`=?',[$v,$key]);}$logo=upload_image('logo');if($logo)q("INSERT INTO settings(`key`,value) VALUES ('logo',?) ON DUPLICATE KEY UPDATE value=VALUES(value)",[$logo]);audit('Ayarlar saxlanıldı');});flash('Ayarlar saxlanıldı.');go('settings');
        case 'import_preview':require __DIR__.'/Excel.php';$id=Excel::preview($_FILES['excel']??[],store_id());go('import',['id'=>$id]);
        case 'import_commit':require __DIR__.'/Excel.php';$id=integer($_POST['id'],1);Excel::commit($id,(string)$_POST['mode']);flash('Excel importu tamamlandı.');go('import',['id'=>$id]);
        case 'backup':require_perm('backup');require __DIR__.'/backup.php';download_backup();
        default:throw new UserError('Əməliyyat tanınmadı.');
    }
    flash('Əməliyyat uğurla tamamlandı.');go('document',['id'=>integer($_POST['id'],1)]);
 }
} catch(Throwable $e){flash(error_message($e),'error');if(!user())$route='login';}
if(!user()){$route='login';require __DIR__.'/login.php';exit;}
try{
    if($route==='api_products'){
        if(!allowed('products')&&!allowed('purchase')&&!allowed('sale')&&!allowed('service')&&!allowed('transfer')&&!allowed('count'))throw new UserError('İcazəniz yoxdur.');
        $s=store_id();assert_store($s);$term=text($_GET['q']??'',100);$like='%'.$term.'%';
        $rows=all('SELECT p.id,p.name,p.sku,p.barcode,p.sell_price,p.buy_price,p.is_serial,COALESCE(st.qty,0) qty FROM products p LEFT JOIN product_store_stock st ON st.product_id=p.id AND st.store_id=? WHERE p.active=1 AND p.deleted_at IS NULL AND (p.name LIKE ? OR p.barcode=? OR p.sku LIKE ? OR EXISTS (SELECT 1 FROM product_serials ps JOIN serial_identifiers si ON si.serial_id=ps.id WHERE ps.product_id=p.id AND ps.store_id=? AND si.identifier=?)) ORDER BY (p.barcode=?) DESC,p.name LIMIT 30',[$s,$like,$term,$like,$s,$term,$term]);
        if(!allowed('profit'))foreach($rows as &$row)unset($row['buy_price']);unset($row);
        header('Content-Type: application/json; charset=utf-8');echo json_encode($rows,JSON_UNESCAPED_UNICODE);exit;
    }
    if($route==='export'){require __DIR__.'/export.php';exit;}
    $routes=['debts'=>'debts_page.php','dashboard'=>'dashboard.php','catalog'=>'catalog_page.php','edit'=>'catalog_page.php','product'=>'product_page.php','users'=>'users_page.php','documents'=>'documents_page.php','new'=>'new_document.php','document'=>'document_page.php','inventory'=>'inventory_page.php','cash'=>'cash_page.php','reports'=>'reports_page.php','settings'=>'settings_page.php','import'=>'import_page.php','exports'=>'export_page.php','audit'=>'audit_page.php','backup'=>'backup_page.php','party'=>'party_page.php','label'=>'label_page.php'];
    if(!isset($routes[$route])){http_response_code(404);throw new UserError('Səhifə tapılmadı.');}
    require __DIR__.'/pages/'.$routes[$route];
}catch(Throwable $e){if(!headers_sent())http_response_code($e instanceof UserError?403:500);if(!headers_sent())header_view('Əməliyyat mümkün olmadı');echo '<div class="card-box"><p>'.e(error_message($e)).'</p>'.link_to('dashboard','İdarə panelinə qayıt').'</div>';footer_view();}
