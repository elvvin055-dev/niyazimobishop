<?php
if (!defined('MOBISHOP_ENTRY') && PHP_SAPI !== 'cli') { http_response_code(403); exit; }

function download_backup():never{
 require_perm('backup');audit('Database backup yükləndi');
 // Download is streamed; its completion marker identifies truncated backups.
 while(ob_get_level()>(int)($GLOBALS['mshop_ob_start']??0))ob_end_flush();
 $tables=q('SHOW FULL TABLES WHERE Table_type = \'BASE TABLE\'')->fetchAll(PDO::FETCH_COLUMN);
 db()->exec('SET TRANSACTION ISOLATION LEVEL REPEATABLE READ');db()->beginTransaction();
 header('Content-Type: application/sql; charset=utf-8');header('Content-Disposition: attachment; filename="MobiShop_Backup_'.date('Y-m-d_His').'.sql"');
 echo "-- MobiShop Niyazi backup\nSET NAMES utf8mb4;\nSET FOREIGN_KEY_CHECKS=0;\n";
 try{foreach($tables as $t){if(!preg_match('/^[a-z_]+$/D',$t))continue;$schema=q("SHOW CREATE TABLE `$t`")->fetch(PDO::FETCH_NUM)[1];echo "\nDROP TABLE IF EXISTS `$t`;\n$schema;\n";
  // Primary-key-independent paging under one consistent snapshot keeps memory bounded.
  $offset=0;do{$rows=all("SELECT * FROM `$t` LIMIT 250 OFFSET $offset");foreach($rows as $row){$values=array_map(fn($v)=>$v===null?'NULL':db()->quote((string)$v),array_values($row));echo 'INSERT INTO `'.$t.'` (`'.implode('`,`',array_keys($row)).'`) VALUES ('.implode(',',$values).");\n";}$offset+=250;}while(count($rows)===250);
 }db()->commit();echo "SET FOREIGN_KEY_CHECKS=1;\n-- BACKUP COMPLETE\n";}catch(Throwable $e){if(db()->inTransaction())db()->rollBack();error_log((string)$e);echo "\n-- BACKUP FAILED: incomplete file\n";}exit;
}
