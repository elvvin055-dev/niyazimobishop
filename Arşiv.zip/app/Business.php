<?php
declare(strict_types=1);
if (!defined('MOBISHOP_ENTRY') && PHP_SAPI !== 'cli') { http_response_code(403); exit; }

/** All posted financial/stock documents are immutable; corrections use linked documents.
 * Money is integer qəpik; quantities are whole units. Store row locks serialize writers.
 */
final class Business {
    public static function lockStores(array $ids): void {
        $ids=array_unique(array_map('intval',$ids)); sort($ids);
        foreach($ids as $id) if(!one('SELECT id FROM stores WHERE id=? AND active=1 FOR UPDATE',[$id])) throw new UserError('Aktiv mağaza tapılmadı.');
    }
    public static function stock(int $s,int $p): array {
        q('INSERT IGNORE INTO product_store_stock(store_id,product_id) VALUES (?,?)',[$s,$p]);
        return one('SELECT * FROM product_store_stock WHERE store_id=? AND product_id=? FOR UPDATE',[$s,$p]);
    }
    public static function move(int $s,int $p,int $delta,int $cost,?int $doc,string $reason): void {
        $st=self::stock($s,$p); $new=(int)$st['qty']+$delta;
        if($new<0) throw new UserError('Stok kifayət etmir. Məhsul #'.$p);
        $avg=(int)$st['avg_cost'];
        if($delta>0) $avg=(int)round(((int)$st['qty']*$avg+$delta*$cost)/$new);
        q('UPDATE product_store_stock SET qty=?,avg_cost=? WHERE store_id=? AND product_id=?',[$new,$avg,$s,$p]);
        insert('stock_movements',['store_id'=>$s,'product_id'=>$p,'document_id'=>$doc,'user_id'=>user()['id'],'delta'=>$delta,'balance'=>$new,'unit_cost'=>$cost,'reason'=>$reason]);
    }
    public static function register(int $s): array {
        $r=one('SELECT * FROM cash_registers WHERE store_id=? AND closed_at IS NULL FOR UPDATE',[$s]);
        if(!$r) throw new UserError('Əvvəlcə bu mağazada kassanın açılışını edin.'); return $r;
    }
    public static function cash(int $s,?int $doc,int $amount,string $method,string $reason): void {
        if(!in_array($method,['cash','card','bank'],true)) throw new UserError('Ödəniş üsulu düzgün deyil.');
        if($amount===0) return;
        $r=self::register($s);
        if($amount<0 && $method==='cash') {
            $balance=(int)$r['opening']+(int)val("SELECT COALESCE(SUM(amount),0) FROM cash_transactions WHERE register_id=? AND method='cash'",[$r['id']]);
            if($balance+$amount<0) throw new UserError('Kassada kifayət qədər nağd pul yoxdur.');
        }
        insert('cash_transactions',['store_id'=>$s,'register_id'=>$r['id'],'document_id'=>$doc,'user_id'=>user()['id'],'method'=>$method,'amount'=>$amount,'reason'=>$reason]);
    }
    public static function cashOpen(int $s,int $amount): int {
        require_perm('cash'); assert_store($s);
        return atomic(function()use($s,$amount){ self::lockStores([$s]);
            if(one('SELECT id FROM cash_registers WHERE store_id=? AND closed_at IS NULL',[$s])) throw new UserError('Kassa artıq açıqdır.');
            $id=insert('cash_registers',['store_id'=>$s,'user_id'=>user()['id'],'opening'=>$amount]); audit('Kassa açıldı',$id,$s); return $id;
        });
    }
    public static function cashClose(int $s,int $actual): void {
        require_perm('cash'); assert_store($s);
        atomic(function()use($s,$actual){self::lockStores([$s]);$r=self::register($s);
            $expected=(int)$r['opening']+(int)val("SELECT COALESCE(SUM(amount),0) FROM cash_transactions WHERE register_id=? AND method='cash'",[$r['id']]);
            update('cash_registers',['expected'=>$expected,'actual'=>$actual,'difference'=>$actual-$expected,'closed_at'=>date('Y-m-d H:i:s')],(int)$r['id']);audit('Kassa bağlandı',(int)$r['id'],$s,['expected'=>$expected,'actual'=>$actual]);
        });
    }
    private static function person(?int $id,string $table,int $store): ?int {
        if(!$id) return null;
        if(!one("SELECT id FROM $table WHERE id=? AND store_id=? AND deleted_at IS NULL",[$id,$store])) throw new UserError('Müştəri / təchizatçı bu mağazaya aid deyil.'); return $id;
    }
    public static function create(string $type,array $in): int {
        if(!in_array($type,['sale','purchase','expense','income','transfer','count','service'],true)) throw new UserError('Əməliyyat tanınmadı.');
        require_perm($type); $s=integer($in['store_id']??0,1); assert_store($s);
        $key=text($in['key']??'',64,true); if(!preg_match('/^[a-f0-9]{64}$/D',$key)) throw new UserError('Əməliyyat açarı düzgün deyil.');
        return atomic(function()use($type,$in,$s,$key){
            $target=$type==='transfer'?integer($in['target_store_id']??0,1):null;
            if($target===$s) throw new UserError('Fərqli mağaza seçin.');
            // Sending to any active store is permitted; receiving needs target-store membership.
            self::lockStores($target?[$s,$target]:[$s]);
            $existing=one('SELECT id,user_id FROM documents WHERE idempotency_key=?',[$key]);
            if($existing) {if((int)$existing['user_id']!==(int)user()['id']) throw new UserError('Əməliyyat açarı istifadə edilib.'); return (int)$existing['id'];}
            $customer=self::person((int)($in['customer_id']??0),'customers',$s);
            $supplier=self::person((int)($in['supplier_id']??0),'suppliers',$s);
            if($type==='purchase' && $customer && $supplier) throw new UserError('Alış üçün ya təchizatçı, ya da satıcı müştəri seçin; hər ikisi deyil.');
            $tech=$type==='service'?(int)($in['technician_id']??user()['id']):null;
            if($tech && !one('SELECT u.id FROM users u JOIN store_users su ON su.user_id=u.id WHERE u.id=? AND su.store_id=? AND u.active=1',[$tech,$s]) && $tech!==(int)user()['id']) throw new UserError('Usta mağazaya aid deyil.');
            $expenseCategory=$type==='expense'?integer($in['expense_category_id']??0,1):null;
            $doc=insert('documents',['expense_category_id'=>$expenseCategory,'type'=>$type,'store_id'=>$s,'target_store_id'=>$target,'user_id'=>user()['id'],'customer_id'=>$customer,'supplier_id'=>$supplier,'status'=>match($type){'transfer'=>'sent','count'=>'draft','service'=>'received',default=>'posted'},'note'=>text($in['note']??'',5000),'idempotency_key'=>$key,'service_model'=>$type==='service'?text($in['service_model']??'',120):null,'service_imei'=>$type==='service'?text($in['service_imei']??'',30):null,'technician_id'=>$tech,'estimate'=>$type==='service'?cents($in['estimate']??'0'):0,'received_at'=>$type==='service'?date('Y-m-d H:i:s'):null]);
            $total=0; $costTotal=0; $discount=0;
            if(in_array($type,['expense','income'],true)) {
                $total=cents($in['amount']??'0'); if($total<=0) throw new UserError('Məbləğ sıfırdan böyük olmalıdır.');
            } elseif($type!=='service') {
                $rows=$in['items']??[]; if(!is_array($rows)||count($rows)<1||count($rows)>100) throw new UserError('1–100 məhsul seçin.');
                $prepared=[]; $seen=[]; $gross=0;
                foreach($rows as $row) {
                    $pid=integer($row['product_id']??0,1); if(isset($seen[$pid])) throw new UserError('Eyni məhsulu bir sətirdə birləşdirin. IMEI-li məhsullar üçün ayrıca sənəd yaradın.'); $seen[$pid]=true;
                    $p=one('SELECT * FROM products WHERE id=? AND active=1 AND deleted_at IS NULL FOR UPDATE',[$pid]); if(!$p) throw new UserError('Məhsul tapılmadı.');
                    $qty=integer($row['qty']??0,$type==='count'?0:1); $st=self::stock($s,$pid);
                    if($p['is_serial'] && ($qty!==1 || $type==='count')) throw new UserError('IMEI-li məhsul: hər sətirdə 1 ədəd; sayım düzəlişi ilə dəyişdirilə bilməz.');
                    $price=match($type){'sale'=>(int)$p['sell_price'],'purchase'=>cents($row['price']??'0'),default=>0};
                    $lineDiscount=$type==='sale'?cents($row['discount']??'0'):0;
                    if($lineDiscount>$price*$qty) throw new UserError('Endirim məbləği satışdan böyükdür.');
                    $gross+=$price*$qty; $discount+=$lineDiscount;
                    $prepared[]=[$p,$qty,$price,$lineDiscount,$row,$st];
                }
                $cart=$type==='sale'?cents($in['discount']??'0'):0; $discount+=$cart;
                if($discount>0) {
                    require_perm('discount'); $limit=user()['role']==='super'?100:(float)user()['discount_limit'];
                    if($discount>$gross || $discount*100>$gross*$limit) throw new UserError('Endirim icazə limitini keçir.');
                }
                $base=$gross-($discount-$cart); $remainingCart=$cart;
                foreach($prepared as $idx=>[$p,$qty,$price,$ld,$row,$st]) {
                    $pid=(int)$p['id']; $cost=$type==='purchase'?$price:(int)$st['avg_cost'];
                    $allocation=$idx===count($prepared)-1?$remainingCart:($base>0?(int)floor($cart*($price*$qty-$ld)/$base):0); $remainingCart-=$allocation;
                    $ld+=$allocation; $lineTotal=$price*$qty-$ld;
                    $serial=null;
                    if($p['is_serial']) {
                        if($type==='purchase') {
                            $imei=text($row['imei']??'',30,true); if(!preg_match('/^\d{15}$/D',$imei)) throw new UserError('IMEI 15 rəqəm olmalıdır.');
                            $imei2=text($row['imei2']??'',30); if($imei2!=='' && !preg_match('/^\d{15}$/D',$imei2)) throw new UserError('IMEI 2 düzgün deyil.');
                            $sn=text($row['serial_number']??'',100);
                            $serial=insert('product_serials',['product_id'=>$pid,'store_id'=>$s,'imei'=>$imei,'imei2'=>$imei2?:null,'serial_number'=>$sn?:null,'status'=>'stock','cost'=>$cost,'purchase_id'=>$doc]);
                            foreach(['imei'=>$imei,'imei2'=>$imei2,'serial'=>$sn] as $kind=>$identifier) if($identifier!=='') insert('serial_identifiers',['identifier'=>$identifier,'serial_id'=>$serial,'kind'=>$kind]);
                        } else {
                            $sr=one("SELECT ps.* FROM product_serials ps JOIN serial_identifiers si ON si.serial_id=ps.id WHERE si.identifier=? AND ps.store_id=? AND ps.product_id=? AND ps.status='stock' FOR UPDATE",[text($row['imei']??'',100,true),$s,$pid]);
                            if(!$sr) throw new UserError('IMEI bu mağazanın stokunda deyil.'); $serial=(int)$sr['id'];
                            update('product_serials',['status'=>$type==='sale'?'sold':'transit','sale_id'=>$type==='sale'?$doc:null],$serial);
                        }
                    }
                    insert('document_items',['document_id'=>$doc,'product_id'=>$pid,'serial_id'=>$serial,'qty'=>$type==='count'?(int)$st['qty']:$qty,'counted_qty'=>$type==='count'?$qty:null,'unit_price'=>$price,'unit_cost'=>$cost,'discount'=>$ld,'line_total'=>$lineTotal]);
                    if($type==='purchase') self::move($s,$pid,$qty,$cost,$doc,'purchase');
                    if(in_array($type,['sale','transfer'],true)) self::move($s,$pid,-$qty,$cost,$doc,$type);
                    $total+=$lineTotal; $costTotal+=$cost*$qty;
                }
            }
            $paid=0;
            if(in_array($type,['sale','purchase','expense','income'],true)) {
                foreach(['cash','card','bank'] as $method) {
                    $amount=cents($in[$method]??'0'); $paid+=$amount;
                    self::cash($s,$doc,in_array($type,['purchase','expense'],true)?-$amount:$amount,$method,$type);
                }
                if($paid>$total) throw new UserError('Ödəniş yekundan böyükdür. Qaytarılacaq pulu ödənişə daxil etməyin.');
                if($paid<$total && (($type==='sale'&&!$customer)||($type==='purchase'&&!$supplier&&!$customer)||in_array($type,['expense','income'],true))) throw new UserError('Tam ödəniş edin və ya borc üçün müştəri/təchizatçı seçin.');
            }
            update('documents',['total'=>$total,'cost_total'=>$costTotal,'discount'=>$discount,'paid'=>$paid],$doc);
            audit($type.' yaradıldı',$doc,$s,['total'=>$total,'paid'=>$paid]); return $doc;
        });
    }
    public static function receiveTransfer(int $id,bool $cancel=false): void {
        require_perm('transfer'); $d=scoped_doc($id);
        if($d['type']!=='transfer') throw new UserError('Transfer sənədi deyil.');
        assert_store((int)($cancel?$d['store_id']:$d['target_store_id']));
        atomic(function()use($id,$d,$cancel){ self::lockStores([(int)$d['store_id'],(int)$d['target_store_id']]); $d=scoped_doc($id,true);
            if($d['status']!=='sent') throw new UserError('Transfer artıq işlənib.');
            $dest=(int)($cancel?$d['store_id']:$d['target_store_id']);
            foreach(all('SELECT * FROM document_items WHERE document_id=? ORDER BY product_id',[$id]) as $it){
                self::move($dest,(int)$it['product_id'],(int)$it['qty'],(int)$it['unit_cost'],$id,$cancel?'transfer_cancel':'transfer_receive');
                if($it['serial_id']) update('product_serials',['store_id'=>$dest,'status'=>'stock'],(int)$it['serial_id']);
            }
            update('documents',['status'=>$cancel?'cancelled':'received'],$id);audit($cancel?'Transfer ləğvi':'Transfer qəbulu',$id,$dest);
        });
    }
    public static function approveCount(int $id): void {
        require_perm('count');$d=scoped_doc($id); if($d['type']!=='count') throw new UserError('Sayım sənədi deyil.');
        atomic(function()use($id,$d){self::lockStores([(int)$d['store_id']]); $d=scoped_doc($id,true);
            if($d['status']!=='draft') throw new UserError('Sayım artıq təsdiqlənib.');
            foreach(all('SELECT * FROM document_items WHERE document_id=? ORDER BY product_id',[$id]) as $it){
                $st=self::stock((int)$d['store_id'],(int)$it['product_id']);
                if((int)$st['qty']!==(int)$it['qty']) throw new UserError('Sayım yaradıldıqdan sonra stok dəyişib. Yeni sayım yaradın.');
                self::move((int)$d['store_id'],(int)$it['product_id'],(int)$it['counted_qty']-(int)$it['qty'],(int)$st['avg_cost'],$id,'count');
            }
            update('documents',['status'=>'posted'],$id); audit('Sayım təsdiqi',$id,(int)$d['store_id']);
        });
    }
    public static function returnedTotal(int $id): int { return (int)val("SELECT COALESCE(SUM(total),0) FROM documents WHERE reference_id=? AND type='return'",[$id]); }
    private static function claimOperation(int $id,string $kind,array $in): bool {
        $key=$in['request_key']??(PHP_SAPI==='cli'?token():'');
        if(!is_string($key)||!preg_match('/^[a-f0-9]{64}$/D',$key))throw new UserError('Əməliyyat açarı düzgün deyil. Səhifəni yeniləyin.');
        $old=one('SELECT * FROM operation_keys WHERE request_key=?',[$key]);
        if($old){if((int)$old['document_id']!==$id||(int)$old['user_id']!==(int)user()['id']||$old['kind']!==$kind)throw new UserError('Əməliyyat açarı istifadə edilib.');return false;}
        insert('operation_keys',['request_key'=>$key,'document_id'=>$id,'user_id'=>user()['id'],'kind'=>$kind]);return true;
    }
    public static function payment(int $id,array $in): void {
        $d=scoped_doc($id); if(!in_array($d['type'],['sale','purchase','service'],true)) throw new UserError('Bu sənədə ödəniş edilmir.');
        atomic(function()use($id,$d,$in){self::lockStores([(int)$d['store_id']]);$d=scoped_doc($id,true);
            if(!self::claimOperation($id,'payment',$in))return;
            if(in_array($d['status'],['cancelled','received','diagnosis','waiting','repair'],true)) throw new UserError('Servis üçün əvvəlcə Hazırdır statusunu seçin.');
            $amount=cents($in['amount']??'0');$debt=(int)$d['total']-(int)$d['paid']-self::returnedTotal($id);
            if($amount<=0||$amount>$debt) throw new UserError('Ödəniş qalıq borcdan böyükdür və ya sıfırdır.');
            self::cash((int)$d['store_id'],$id,$d['type']==='purchase'?-$amount:$amount,(string)($in['method']??''),'debt_payment');
            update('documents',['paid'=>(int)$d['paid']+$amount],$id);audit('Borc ödənişi',$id,(int)$d['store_id'],['amount'=>$amount]);
        });
    }
    public static function returnSale(int $id,array $in): int {
        require_perm('return');$sale=scoped_doc($id); if($sale['type']!=='sale') throw new UserError('Satış sənədi deyil.');
        return atomic(function()use($id,$in,$sale){self::lockStores([(int)$sale['store_id']]);$sale=scoped_doc($id,true);
            $item=one('SELECT * FROM document_items WHERE id=? AND document_id=? FOR UPDATE',[(int)($in['item_id']??0),$id]); if(!$item) throw new UserError('Satış sətri tapılmadı.');
            $qty=integer($in['qty']??0,1); if($qty>(int)$item['qty']-(int)$item['returned_qty']) throw new UserError('Qaytarılan miqdar satışdan böyükdür.');
            $already=(int)val('SELECT COALESCE(SUM(line_total),0) FROM document_items WHERE reference_item_id=?',[$item['id']]);
            $amount=$qty===(int)$item['qty']-(int)$item['returned_qty']?(int)$item['line_total']-$already:(int)floor((int)$item['line_total']*$qty/(int)$item['qty']);
            $refund=min($amount,(int)$sale['paid']); $cost=$qty*(int)$item['unit_cost'];
            $rid=insert('documents',['type'=>'return','store_id'=>$sale['store_id'],'user_id'=>user()['id'],'customer_id'=>$sale['customer_id'],'reference_id'=>$id,'status'=>'posted','total'=>$amount,'cost_total'=>$cost,'paid'=>$refund,'note'=>text($in['note']??'',1000,true),'idempotency_key'=>text($in['key']??'',64,true)]);
            insert('document_items',['document_id'=>$rid,'product_id'=>$item['product_id'],'serial_id'=>$item['serial_id'],'reference_item_id'=>$item['id'],'qty'=>$qty,'unit_price'=>$item['unit_price'],'unit_cost'=>$item['unit_cost'],'line_total'=>$amount]);
            self::move((int)$sale['store_id'],(int)$item['product_id'],$qty,(int)$item['unit_cost'],$rid,'return');
            self::cash((int)$sale['store_id'],$rid,-$refund,(string)($in['method']??'cash'),'return');
            update('document_items',['returned_qty'=>(int)$item['returned_qty']+$qty],(int)$item['id']);
            update('documents',['paid'=>(int)$sale['paid']-$refund],$id);
            if($item['serial_id']) update('product_serials',['status'=>'stock','sale_id'=>null],(int)$item['serial_id']);
            audit('Satış qaytarıldı',$rid,(int)$sale['store_id'],['refund'=>$refund]);return $rid;
        });
    }
    public static function servicePart(int $id,array $in): void {
        require_perm('service');$d=scoped_doc($id);if($d['type']!=='service') throw new UserError('Servis sənədi deyil.');
        atomic(function()use($id,$in,$d){self::lockStores([(int)$d['store_id']]);$d=scoped_doc($id,true);
            if(!self::claimOperation($id,'service_part',$in))return;
            if(in_array($d['status'],['ready','delivered','cancelled'],true)) throw new UserError('Bağlı servisə hissə əlavə edilmir.');
            $pid=integer($in['product_id']??0,1);$qty=integer($in['qty']??0,1);
            $p=one('SELECT * FROM products WHERE id=? AND active=1 AND deleted_at IS NULL',[$pid]);if(!$p||$p['is_serial']) throw new UserError('Hissə məhsulu seçin (IMEI-siz).');
            $st=self::stock((int)$d['store_id'],$pid);$cost=(int)$st['avg_cost'];$price=(int)$p['sell_price'];
            insert('document_items',['document_id'=>$id,'product_id'=>$pid,'qty'=>$qty,'unit_price'=>$price,'unit_cost'=>$cost,'line_total'=>$qty*$price]);
            self::move((int)$d['store_id'],$pid,-$qty,$cost,$id,'service_part');
            update('documents',['cost_total'=>(int)$d['cost_total']+$qty*$cost,'total'=>(int)$d['total']+$qty*$price],$id); audit('Servis hissəsi',$id,(int)$d['store_id']);
        });
    }
    public static function serviceStatus(int $id,array $in): void {
        require_perm('service');$d=scoped_doc($id);if($d['type']!=='service') throw new UserError('Servis sənədi deyil.');
        atomic(function()use($id,$in,$d){self::lockStores([(int)$d['store_id']]);$d=scoped_doc($id,true);
            $status=$in['status']??'';
            $transitions=['received'=>['diagnosis','cancelled'],'diagnosis'=>['waiting','repair','ready','cancelled'],'waiting'=>['repair','cancelled'],'repair'=>['waiting','ready','cancelled'],'ready'=>['delivered']];
            if(!in_array($status,$transitions[$d['status']]??[],true)) throw new UserError('Status keçidi düzgün deyil.');
            $data=['status'=>$status];
            if($status==='ready') { $labor=cents($in['labor']??'0'); $parts=(int)val('SELECT COALESCE(SUM(line_total),0) FROM document_items WHERE document_id=?',[$id]);$data+=['labor'=>$labor,'total'=>$parts+$labor,'recognized_at'=>date('Y-m-d H:i:s')]; }
            if($status==='delivered' && (int)$d['paid']<(int)$d['total'] && !$d['customer_id']) throw new UserError('Ödənişi tamamlayın.');
            if($status==='cancelled') {
                if((int)$d['paid']>0) throw new UserError('Ödənişli servis ləğv edilmir.');
                foreach(all('SELECT * FROM document_items WHERE document_id=?',[$id]) as $it) self::move((int)$d['store_id'],(int)$it['product_id'],(int)$it['qty'],(int)$it['unit_cost'],$id,'service_cancel');
                $data+=['total'=>0,'cost_total'=>0];
            }
            update('documents',$data,$id);audit('Servis statusu',$id,(int)$d['store_id'],['status'=>$status]);
        });
    }
}
