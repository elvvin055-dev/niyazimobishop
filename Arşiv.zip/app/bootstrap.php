<?php
declare(strict_types=1);
if (!defined('MOBISHOP_ENTRY') && PHP_SAPI !== 'cli') { http_response_code(403); exit; }
if (!defined('MOBISHOP_ENTRY')) define('MOBISHOP_ENTRY', true);
require_once __DIR__.'/runtime.php';
date_default_timezone_set('Asia/Baku');
ini_set('display_errors', '0');
ini_set('log_errors', '1');
$logFile=dirname(__DIR__).'/storage/logs/php-error.php';
if (!is_file($logFile)) @file_put_contents($logFile,"<?php http_response_code(403); exit; ?>\n",LOCK_EX);
ini_set('error_log',$logFile);
if (PHP_SAPI !== 'cli') {
    header('X-Content-Type-Options: nosniff');
    header('X-Frame-Options: SAMEORIGIN');
    header('Referrer-Policy: same-origin');
    header("Content-Security-Policy: default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; frame-ancestors 'self'; base-uri 'self'; form-action 'self'");
    header('Cache-Control: no-store');
}
$configFile=dirname(__DIR__).'/config/config.php';
$config=is_file($configFile)?require $configFile:[];
if (!is_array($config)) throw new RuntimeException('Invalid configuration structure.');
if (PHP_SAPI !== 'cli') {
    $savePath=dirname(__DIR__).'/storage/sessions';
    if (!is_dir($savePath)) @mkdir($savePath,0755,true);
    if (!is_writable($savePath)) mshop_recovery('Sessiya qovluğuna yazmaq mümkün deyil','Hosting panelində storage/sessions qovluğunun mövcudluğunu və sahiblik/yazma icazəsini yoxlayın.',[],503);
    ini_set('session.use_strict_mode','1');
    ini_set('session.use_only_cookies','1');
    ini_set('session.gc_maxlifetime','3600');
    ini_set('session.gc_probability','1');
    ini_set('session.gc_divisor','100');
    session_save_path($savePath);
    session_name('mobishop_'.substr(hash('sha256',dirname(__DIR__)),0,12));
    $secure=$config['secure_cookie']??'auto';
    $secure=$secure==='auto'?mshop_https():(bool)$secure;
    $path=str_replace('\\','/',dirname($_SERVER['SCRIPT_NAME']??'/index.php'));
    $path=$path==='/'||$path==='.'?'/':rtrim($path,'/').'/';
    session_set_cookie_params(['httponly'=>true,'secure'=>$secure,'samesite'=>'Lax','path'=>$path]);
    if (!@session_start()) mshop_recovery('Sessiya başlatmaq mümkün olmadı','PHP sessiya saxlaması uğursuzdur. Hosting yoxlamasını açın və yazma icazələrini yoxlayın.',[],503);
    if(isset($_SESSION['last_seen'])&&time()-$_SESSION['last_seen']>3600){$_SESSION=[];session_regenerate_id(true);}
    $_SESSION['last_seen']=time();
    if($_SERVER['REQUEST_METHOD']==='POST'&&!mshop_https()&&!mshop_local())mshop_recovery('HTTPS tələb olunur','Parol və biznes məlumatlarını təhlükəsiz ötürmək üçün saytı https:// ünvanında açın. Hosting panelində SSL sertifikatını aktiv edin.',[],403);
}
require_once __DIR__.'/helpers.php';
require_once __DIR__.'/auth.php';
require_once __DIR__.'/Business.php';
