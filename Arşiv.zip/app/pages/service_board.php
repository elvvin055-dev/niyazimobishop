<?php
if (!defined('MOBISHOP_ENTRY') && PHP_SAPI !== 'cli') { http_response_code(403); exit; }

$columns=['received','diagnosis','repair','waiting','ready','delivered'];$grouped=[];foreach($rows as $d)$grouped[$d['status']][]=$d;if(!empty($grouped['cancelled']))$columns[]='cancelled';
echo '<p class="table-note mb-3">'.icon('info').' Kanban cari filtrlər və səhifədəki '.count($rows).' sifarişi göstərir. Sifariş açıldıqda mövcud status qaydaları tətbiq olunur.</p><div class="kanban">';
foreach($columns as $status){$tickets=$grouped[$status]??[];echo '<section class="kanban-column"><div class="kanban-heading">'.status_badge($status).'<span class="count-badge">'.count($tickets).'</span></div>';
 foreach($tickets as $d){$final=in_array($d['status'],['ready','delivered','cancelled'],true);echo '<a class="kanban-card" href="'.e(url('document',['id'=>$d['id']])).'"><div class="kanban-card-head"><span>SRV-'.str_pad((string)$d['id'],5,'0',STR_PAD_LEFT).'</span>'.icon('arrow-up-right').'</div><h3>'.e($d['service_model']?:'Model qeyd edilməyib').'</h3><div class="muted">'.e($d['customer_name']?:'Müştəri qeyd edilməyib').'</div><div class="kanban-contact">'.e($d['customer_phone']??'').'</div><p class="kanban-problem">'.e($d['note']).'</p><div class="kanban-imei">IMEI: '.e($d['service_imei']?:'—').'</div><div class="kanban-assignee">'.icon('user-round').e($d['technician_name']?:'Təyin edilməyib').'</div><div class="kanban-meta"><span>'.e(dt($d['created_at'])).'</span><div><small>'.($final?'Yekun':'Təxmin').'</small><strong>'.money($final?$d['total']:$d['estimate']).'</strong></div></div></a>';}
 if(!$tickets)echo '<div class="kanban-empty">'.icon('inbox').'<span>Bu mərhələdə sifariş yoxdur</span></div>';echo '</section>';
}echo '</div>';
