<?php
if (!defined('MOBISHOP_ENTRY') && PHP_SAPI !== 'cli') { http_response_code(403); exit; }

require_perm('backup');header_view('Database Backup');echo '<div class="card-box"><h2>Verilənlər bazasının ehtiyat nüsxəsi</h2><p class="muted">SQL faylı birbaşa cihazınıza yüklənir. Bütün mağazalar, istifadəçilər və şəxsi məlumatları ehtiva edir. Faylı şifrəli və təhlükəsiz yerdə saxlayın. Şəkillər ayrıca uploads qovluğundadır.</p><div class="notice">Böyük bazada hostingin PHP vaxt limitinə görə export kəsilə bilər. Yüklənmiş faylın sonundakı “BACKUP COMPLETE” sətrini yoxlayın. Bərpa hostingin phpMyAdmin panelində, boş bazaya edilir.</div>';form_start('backup');submit('SQL backup yüklə');echo '</form></div>';footer_view();
