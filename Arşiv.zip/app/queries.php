<?php
if (!defined('MOBISHOP_ENTRY') && PHP_SAPI !== 'cli') { http_response_code(403); exit; }

function document_query(string $type):array{
    if(!array_key_exists($type,doc_names()))throw new UserError('Sənəd növü düzgün deyil.');require_perm($type);
    [$from,$to]=date_range();$where='d.type=? AND d.created_at>=? AND d.created_at<?';$args=[$type,$from,$to];$s=store_id();assert_store($s);
    if($type==='transfer'){$where.=' AND (d.store_id=? OR d.target_store_id=?)';$args[]=$s;$args[]=$s;}else{$where.=' AND d.store_id=?';$args[]=$s;}
    if(in_array(user()['role'],['sales','service'],true)){$where.=' AND (d.user_id=?'.($type==='service'?' OR d.technician_id=?':'').')';$args[]=user()['id'];if($type==='service')$args[]=user()['id'];}
    $search=text($_GET['q']??'',100);if($search!==''){$where.=' AND (CAST(d.id AS CHAR)=? OR d.note LIKE ? OR c.name LIKE ? OR sp.name LIKE ? OR d.service_imei=?)';array_push($args,$search,'%'.$search.'%','%'.$search.'%','%'.$search.'%',$search);}
    if(!empty($_GET['user_id'])&&!in_array(user()['role'],['sales','service'],true)){$where.=' AND d.user_id=?';$args[]=integer($_GET['user_id'],1);}
    if(!empty($_GET['customer_id'])){$where.=' AND d.customer_id=?';$args[]=integer($_GET['customer_id'],1);}
    if(!empty($_GET['supplier_id'])){$where.=' AND d.supplier_id=?';$args[]=integer($_GET['supplier_id'],1);}
    if(!empty($_GET['method'])){if(!in_array($_GET['method'],['cash','card','bank'],true))throw new UserError('Ödəniş üsulu düzgün deyil.');$where.=' AND EXISTS (SELECT 1 FROM cash_transactions ct WHERE ct.document_id=d.id AND ct.method=?)';$args[]=$_GET['method'];}
    return ["FROM documents d JOIN users u ON u.id=d.user_id LEFT JOIN customers c ON c.id=d.customer_id LEFT JOIN suppliers sp ON sp.id=d.supplier_id WHERE $where",$args];
}
function report_data():array{
    require_perm('reports');[$from,$to]=date_range();$ids=array_column(stores(),'id');
    $all=($_GET['scope']??'')==='all';if(!$all)$ids=[store_id()];if(!$ids)return [];
    $ph=implode(',',array_fill(0,count($ids),'?'));
    $group=$_GET['group']??'day';
    [$select,$groupBy,$join]=match($group){
        'store'=>['s.name','s.id,s.name','JOIN stores s ON s.id=d.store_id'],
        'employee'=>['u.name','u.id,u.name','JOIN users u ON u.id=d.user_id'],
        'month'=>["DATE_FORMAT(COALESCE(d.recognized_at,d.created_at),'%Y-%m')","DATE_FORMAT(COALESCE(d.recognized_at,d.created_at),'%Y-%m')",''],
        'year'=>['YEAR(COALESCE(d.recognized_at,d.created_at))','YEAR(COALESCE(d.recognized_at,d.created_at))',''],
        default=>['DATE(COALESCE(d.recognized_at,d.created_at))','DATE(COALESCE(d.recognized_at,d.created_at))','']
    };
    return all("SELECT $select label,
      SUM(CASE WHEN type='sale' THEN total WHEN type='return' THEN -total ELSE 0 END) sales,
      SUM(CASE WHEN type='sale' THEN cost_total WHEN type='return' THEN -cost_total ELSE 0 END) cogs,
      SUM(CASE WHEN type='purchase' THEN total ELSE 0 END) purchases,
      SUM(CASE WHEN type='expense' THEN total ELSE 0 END) expenses,
      SUM(CASE WHEN type='income' THEN total ELSE 0 END) income,
      SUM(CASE WHEN type='service' AND d.status IN ('ready','delivered') THEN total-cost_total ELSE 0 END) service_profit,
      SUM(CASE WHEN type='sale' THEN discount ELSE 0 END) discounts,
      SUM(type='sale') sale_count,SUM(type='return') return_count
      FROM documents d $join WHERE d.store_id IN ($ph) AND COALESCE(d.recognized_at,d.created_at)>=? AND COALESCE(d.recognized_at,d.created_at)<? GROUP BY $groupBy ORDER BY $groupBy DESC LIMIT 1000",[...$ids,$from,$to]);
}
function product_report():array{
    require_perm('reports');$s=store_id();assert_store($s);[$from,$to]=date_range();
    $cat=($_GET['group']??'')==='category';$label=$cat?"COALESCE(c.name,'Kateqoriyasız')":'p.name';$group=$cat?'c.id,c.name':'p.id,p.name';
    return all("SELECT $label label,SUM(IF(d.type='return',-i.qty,i.qty)) qty,SUM(IF(d.type='return',-i.line_total,i.line_total)) sales,SUM(IF(d.type='return',-i.qty*i.unit_cost,i.qty*i.unit_cost)) cogs FROM document_items i JOIN documents d ON d.id=i.document_id JOIN products p ON p.id=i.product_id LEFT JOIN categories c ON c.id=p.category_id WHERE d.store_id=? AND d.type IN ('sale','return') AND d.created_at>=? AND d.created_at<? GROUP BY $group ORDER BY sales DESC LIMIT 1000",[$s,$from,$to]);
}
