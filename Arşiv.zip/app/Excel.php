<?php
declare(strict_types=1);
if (!defined('MOBISHOP_ENTRY') && PHP_SAPI !== 'cli') { http_response_code(403); exit; }

$excelMissing=[];
foreach(['zip','dom','xml','xmlreader','xmlwriter','mbstring','gd','iconv','simplexml'] as $ext)if(!extension_loaded($ext))$excelMissing[]=$ext;
if($excelMissing)throw new UserError('Excel üçün PHP modulları aktiv deyil: '.implode(', ',$excelMissing).'. Hosting yoxlamasına baxın.');
if(!is_file(dirname(__DIR__).'/vendor/autoload.php'))throw new UserError('Excel kitabxanası tam yüklənməyib. Tam paketin vendor qovluğunu yenidən yükləyin.');
require_once dirname(__DIR__).'/vendor/autoload.php';
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\IOFactory;
use PhpOffice\PhpSpreadsheet\Cell\DataType;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;
final class Excel {
    public const HEADERS=['Məhsul adı','SKU','Barkod','Miqdar','Alış qiyməti','Satış qiyməti','Kateqoriya','Marka','Model'];
    public static function download(string $name,array $headers,iterable $rows): never {
        $book=new Spreadsheet();$sheet=$book->getActiveSheet();$i=1;
        foreach([$headers] as $row)foreach(array_values($row) as $col=>$value)$sheet->setCellValueExplicit([$col+1,$i],(string)$value,DataType::TYPE_STRING);
        foreach($rows as $row){$i++;foreach(array_values($row) as $col=>$value)$sheet->setCellValueExplicit([$col+1,$i],(string)($value??''),DataType::TYPE_STRING);}
        $sheet->getStyle('1:1')->getFont()->setBold(true);$sheet->freezePane('A2');$sheet->setAutoFilter($sheet->calculateWorksheetDimension());
        for($c=1;$c<=count($headers);$c++)$sheet->getColumnDimensionByColumn($c)->setWidth(23);
        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');header('Content-Disposition: attachment; filename="'.$name.'.xlsx"');
        (new Xlsx($book))->save('php://output');exit;
    }
    public static function preview(array $file,int $store): int {
        require_perm('import');assert_store($store);
        if(($file['error']??-1)!==UPLOAD_ERR_OK||$file['size']>3*1024*1024||strtolower(pathinfo($file['name'],PATHINFO_EXTENSION))!=='xlsx')throw new UserError('Yalnız .xlsx; maksimum 3 MB.');
        // Guard against compressed zip bombs before PhpSpreadsheet opens the workbook.
        $zip=new ZipArchive();if($zip->open($file['tmp_name'])!==true)throw new UserError('Excel faylı açılmadı.');
        $bytes=0;if($zip->numFiles>1000)throw new UserError('Fayl həddən artıq böyükdür.');
        for($i=0;$i<$zip->numFiles;$i++)$bytes+=$zip->statIndex($i)['size'];$zip->close();if($bytes>20*1024*1024)throw new UserError('Açılmış Excel 20 MB limitini keçir.');
        $reader=IOFactory::createReader('Xlsx');$info=$reader->listWorksheetInfo($file['tmp_name']);
        if(count($info)!==1||$info[0]['totalRows']>1001||$info[0]['totalColumns']>9)throw new UserError('Bir vərəq, maksimum 1000 məhsul və 9 sütun qəbul edilir.');
        $reader->setReadDataOnly(true);$book=$reader->load($file['tmp_name']);$rows=$book->getActiveSheet()->toArray(null,false,false,false);$book->disconnectWorksheets();
        if(array_map('strval',array_shift($rows)??[])!==self::HEADERS)throw new UserError('Sütun başlıqları şablona uyğun deyil. Excel şablonunu yükləyin.');
        return atomic(function()use($rows,$store){
            $batch=insert('import_batches',['store_id'=>$store,'user_id'=>user()['id']]);$skus=[];$barcodes=[];
            foreach($rows as $index=>$row){
                if(count(array_filter($row,fn($x)=>$x!==null&&$x!==''))===0)continue;
                $status='valid';$error='';$data=[];
                try{
                    $data=['name'=>text($row[0]??'',160,true),'sku'=>text($row[1]??'',80,true),'barcode'=>text($row[2]??'',80),'qty'=>integer($row[3]??0),'buy_price'=>cents($row[4]??'0'),'sell_price'=>cents($row[5]??'0'),'category'=>text($row[6]??'',120),'brand'=>text($row[7]??'',120),'model'=>text($row[8]??'',100)];
                    if(isset($skus[$data['sku']])||($data['barcode']!==''&&isset($barcodes[$data['barcode']])))throw new UserError('Fayl daxilində təkrar SKU / barkod.');
                    $skus[$data['sku']]=true;if($data['barcode']!=='')$barcodes[$data['barcode']]=true;
                    $found=all('SELECT id,is_serial FROM products WHERE sku=? OR (barcode IS NOT NULL AND barcode=?)',[$data['sku'],$data['barcode']]);
                    if(count($found)>1)throw new UserError('SKU və barkod müxtəlif məhsullara aiddir.');
                    if($found){if($found[0]['is_serial'])throw new UserError('IMEI-li məhsul alış sənədi ilə daxil edilir.');$status='duplicate';}
                }catch(UserError $e){$status='error';$error=$e->getMessage();}
                insert('import_rows',['batch_id'=>$batch,'line_number'=>$index+2,'payload'=>json_encode($data?:['raw'=>$row],JSON_UNESCAPED_UNICODE),'status'=>$status,'error'=>$error]);
            }
            audit('Excel preview',$batch,$store);return $batch;
        });
    }
    public static function batch(int $id): array {
        require_perm('import');$b=one('SELECT * FROM import_batches WHERE id=?',[$id]);if(!$b)throw new UserError('Import tapılmadı.');assert_store((int)$b['store_id']);
        if(user()['role']!=='super'&&(int)$b['user_id']!==(int)user()['id'])throw new UserError('Bu import sizə aid deyil.');return $b;
    }
    public static function commit(int $id,string $mode): array {
        $b=self::batch($id);if(!in_array($mode,['skip','update'],true))throw new UserError('Import rejimi düzgün deyil.');
        return atomic(function()use($id,$b,$mode){Business::lockStores([(int)$b['store_id']]);$locked=one('SELECT status FROM import_batches WHERE id=? FOR UPDATE',[$id]);if($locked['status']!=='preview')throw new UserError('Import artıq tətbiq edilib.');
            $result=['new'=>0,'updated'=>0,'skipped'=>0,'errors'=>0];
            foreach(all('SELECT * FROM import_rows WHERE batch_id=? ORDER BY id',[$id])as $r){
                if($r['status']==='error'){$result['errors']++;continue;}
                $d=json_decode($r['payload'],true);$found=all('SELECT * FROM products WHERE sku=? OR barcode=? FOR UPDATE',[$d['sku'],$d['barcode']]);
                if(count($found)>1||($found&&($found[0]['is_serial']||$found[0]['deleted_at']))){update('import_rows',['status'=>'error','error'=>'Məhsul dəyişib: konflikt, IMEI və ya silinmiş qeyd.'],(int)$r['id']);$result['errors']++;continue;}
                if($found&&$mode==='skip'){$result['skipped']++;continue;}
                $data=['name'=>$d['name'],'sku'=>$d['sku'],'barcode'=>$d['barcode']?:null,'model'=>$d['model'],'buy_price'=>$d['buy_price'],'sell_price'=>$d['sell_price']];
                foreach(['category'=>'categories','brand'=>'brands'] as $k=>$table){if($d[$k]!==''){q("INSERT IGNORE INTO $table(name) VALUES (?)",[$d[$k]]);$data[$k.'_id']=(int)val("SELECT id FROM $table WHERE name=?",[$d[$k]]);}}
                if($found){$pid=(int)$found[0]['id'];update('products',$data,$pid);$result['updated']++;}else{$pid=insert('products',$data);$result['new']++;}
                if($d['qty']>0)Business::move((int)$b['store_id'],$pid,$d['qty'],$d['buy_price'],null,'opening_import');
            }
            update('import_batches',['status'=>'completed','result'=>json_encode($result)],$id);audit('Excel tətbiq edildi',$id,(int)$b['store_id'],$result);return $result;
        });
    }
}
