<?php
declare(strict_types=1);
if (!defined('MOBISHOP_ENTRY') && PHP_SAPI !== 'cli') { http_response_code(403); exit; }

function user(): ?array {
    if(empty($_SESSION['uid'])) return null;
    static $cache=[]; $id=(int)$_SESSION['uid'];
    return $cache[$id] ??= one('SELECT u.*,r.code role FROM users u JOIN roles r ON r.id=u.role_id WHERE u.id=? AND u.active=1',[$id]);
}
function allowed(string $p): bool {
    $u=user(); if(!$u) return false; if($u['role']==='super') return true;
    $ceilings=['sales'=>['sale','return','cash','customers','products','discount','product_edit'], 'service'=>['service','products','inventory','customers']];
    if(isset($ceilings[$u['role']]) && !in_array($p,$ceilings[$u['role']],true)) return false;
    if($u['role']==='manager' && in_array($p,['users','stores','settings','backup'],true)) return false;
    static $maps=[];
    if(!isset($maps[$u['id']])) {
        $m=array_fill_keys(array_column(all('SELECT permission FROM role_permissions WHERE role_id=?',[$u['role_id']]),'permission'),true);
        foreach(all('SELECT permission,allowed FROM user_permissions WHERE user_id=?',[$u['id']]) as $r) $m[$r['permission']]=(bool)$r['allowed'];
        $maps[$u['id']]=$m;
    }
    return $maps[$u['id']][$p]??false;
}
function require_perm(string $p): void { if(!allowed($p)) { if(!headers_sent())http_response_code(403); throw new UserError('İcazəniz yoxdur.'); } }
function stores(): array {
    if(user()['role']==='super') return all('SELECT * FROM stores WHERE active=1 ORDER BY name');
    return all('SELECT s.* FROM stores s JOIN store_users su ON su.store_id=s.id WHERE su.user_id=? AND s.active=1 ORDER BY s.name',[user()['id']]);
}
function assert_store(int $id): void {
    foreach(stores() as $s) if((int)$s['id']===$id) return;
    throw new UserError('Bu mağazaya giriş icazəniz yoxdur və ya mağaza passivdir.');
}
function store_id(): int {
    $id=(int)($_SESSION['store_id']??0); $ss=stores();
    foreach($ss as $s) if((int)$s['id']===$id) return $id;
    return $_SESSION['store_id']=(int)($ss[0]['id']??0);
}
function scoped_doc(int $id,bool $lock=false): array {
    $d=one('SELECT * FROM documents WHERE id=?'.($lock?' FOR UPDATE':''),[$id]);
    if(!$d) throw new UserError('Sənəd tapılmadı.');
    $s=(int)$d['store_id']; $accessible=false;
    foreach(stores() as $st) if((int)$st['id']===$s || ($d['type']==='transfer' && (int)$st['id']===(int)$d['target_store_id'])) $accessible=true;
    if(!$accessible) throw new UserError('Sənədə giriş icazəniz yoxdur.');
    require_perm($d['type']==='return'?'return':$d['type']);
    if(in_array(user()['role'],['sales','service'],true) && (int)$d['user_id']!==(int)user()['id'] && !($d['type']==='service' && (int)$d['technician_id']===(int)user()['id'])) throw new UserError('Yalnız öz əməliyyatlarınıza baxa bilərsiniz.');
    return $d;
}
function login(string $username,string $password): bool {
    $fp=hash('sha256',strtolower($username).'|'.($_SERVER['REMOTE_ADDR']??''));
    if((int)val('SELECT COUNT(*) FROM login_attempts WHERE fingerprint=? AND created_at>DATE_SUB(NOW(),INTERVAL 15 MINUTE)',[$fp])>=8) throw new UserError('Çox sayda cəhd. 15 dəqiqə sonra yenidən sınayın.');
    $u=one('SELECT * FROM users WHERE username=? AND active=1',[$username]);
    $hash=$u['password_hash']??'$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2uheWG/igi.';
    if(!$u || !password_verify($password,$hash)) { insert('login_attempts',['fingerprint'=>$fp]); return false; }
    session_regenerate_id(true); $_SESSION['uid']=(int)$u['id']; $_SESSION['csrf']=token();
    q('DELETE FROM login_attempts WHERE fingerprint=? OR created_at<DATE_SUB(NOW(),INTERVAL 1 DAY)',[$fp]); audit('Giriş'); return true;
}
