<?php
// Copy the value between quotes into setup.php. Not an admin password.
return '5d3f9a24203a288df8db880868a81dd9fb34a5831dc772cc';
