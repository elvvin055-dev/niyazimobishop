<?php
return [
    'db_host' => 'localhost',
    'db_port' => 3306,
    'db_name' => 'hosting_database_name',
    'db_user' => 'hosting_database_user',
    'db_pass' => 'hosting_database_password',
    'installed' => false,
    // HTTPS/SSL-terminating proxy detection. Public login requires HTTPS.
    'secure_cookie' => 'auto',
    'release' => '2026.10-clean',
];
