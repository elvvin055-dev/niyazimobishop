(()=>{try{const t=localStorage.getItem('mobishop-theme')||'light';document.documentElement.dataset.theme=t==='dark'?'dark':'light';}catch(e){document.documentElement.dataset.theme='light';}})();
