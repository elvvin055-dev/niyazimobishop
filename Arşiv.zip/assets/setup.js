'use strict';
window.lucide?.createIcons({attrs:{'stroke-width':1.7}});
async function runHostChecks(){
 const targets=[...document.querySelectorAll('[data-hosting-checks]')];if(!targets.length)return;
 const results=[];const report=(ok,text)=>{results.push({ok,text});targets.forEach(target=>{target.replaceChildren();results.forEach(result=>{const row=document.createElement('div');row.className='probe-row '+(result.ok?'ok':'bad');const dot=document.createElement('span');dot.className='probe-dot';const label=document.createElement('span');label.textContent=result.text;row.append(dot,label);target.append(row);});});};
 const get=async url=>{const controller=new AbortController();const timeout=setTimeout(()=>controller.abort(),9000);try{return await fetch(url,{cache:'no-store',credentials:'same-origin',signal:controller.signal});}finally{clearTimeout(timeout);}};
 try{const a=await get('health.php?probe=session');const first=await a.json();const b=await get('health.php?probe=session');const second=await b.json();const ok=first.ok&&second.ok&&second.count>first.count;report(ok,ok?'Sessiya və cookie: işləyir':'Cookie saxlanmır. HTTPS və brauzerin cookie icazəsini yoxlayın.');}catch(e){report(false,'Sessiya yoxlaması alınmadı. PHP versiyasını, yazma icazələrini və cookie-ni yoxlayın.');}
 try{const r=await get('assets/app.css');const css=await r.text();const ok=r.ok&&css.includes('--nav');report(ok,ok?'Dizayn faylları: əlçatandır':'CSS faylı tapılmadı və ya hosting müdafiə səhifəsi qaytardı. assets/ qovluğunu yoxlayın.');}catch(e){report(false,'Dizayn fayllarına sorğu alınmadı.');}
 let privateOkay=true;for(const path of ['config/access-check.txt','storage/access-check.txt','database/access-check.txt','vendor/composer/installed.json']){try{const r=await get(path);if(r.status!==403&&r.status!==404)privateOkay=false;}catch(e){privateOkay=false;}}
 report(privateOkay,privateOkay?'Məxfi qovluqlar: 403/404 ilə qorunur':'Məxfi qovluqların qorunması təsdiqlənmədi. .htaccess qaydalarını düzəltmədən canlı istifadəyə keçməyin.');
 const button=document.querySelector('[data-setup-submit]');if(button&&(!privateOkay||results.some(r=>!r.ok))){button.disabled=true;report(false,'Davam etməzdən əvvəl brauzer/Apache yoxlamasındakı problemləri düzəldin və səhifəni yeniləyin.');}
}
runHostChecks();
document.querySelectorAll('form').forEach(form=>form.addEventListener('submit',()=>{
 const button=form.querySelector('button[type=submit]');if(!button)return;
 button.setAttribute('aria-busy','true');const status=document.createElement('p');status.className='setup-progress-text';status.setAttribute('role','status');status.textContent=form.querySelector('[name=setup_action]')?.value==='install'?'Cədvəllər və hesabınız yaradılır. Səhifəni bağlamayın…':'Yoxlanır, zəhmət olmasa gözləyin…';form.append(status);setTimeout(()=>button.disabled=true,50);
}));
