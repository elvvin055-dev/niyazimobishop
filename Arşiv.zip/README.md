# MobiShop Niyazi — təmiz quraşdırma
**Buraxılış: 2026.10-clean · 2 oktyabr 2026**

## Hansı faylı istifadə etməliyəm?

**Yalnız `MobiShop_Niyazi_YEKUN_2026.zip` — tam sistem paketidir.** Köhnə UI patch-lərini bunun üstünə yazmayın. Son premium dizayn, bütün tətbiq faylları, lokal şrift/ikon/qrafik kitabxanaları və hazır `vendor/` bu ZIP-dədir.

Bu paket **yeni, boş database** üçündür. Mövcud database-i avtomatik silmir. Standart admin parolu, demo məhsul və demo satış yoxdur. İlk admini və mağazanı özünüz yaradırsınız.

## 1. Hostingdə hazırlıq

1. Domen üçün **HTTPS/SSL** aktiv edin. Saytı `https://` ilə açın.
2. Domenin PHP versiyasını **8.2, 8.3 və ya 8.4, 64-bit** seçin. Paket lokal olaraq PHP 8.4.26-da yoxlanılıb; bütün versiya/hosting kombinasiyaları ayrıca sınaqdan keçirilməyib.
3. PHP modulları: `pdo_mysql`, `mbstring`, `session`, `json`, `ctype`, `dom`, `xml`, `xmlreader`, `xmlwriter`, `zip`, `fileinfo`, `gd`, `iconv`, `simplexml`. Bunlar panelin PHP modul bölməsindən aktiv olmalıdır. Hosting planınız bunları vermirsə quraşdırmanı zorla davam etdirməyin.
4. Paneldə **yeni, boş MySQL database** və ona bağlı istifadəçi yaradın. İstifadəçiyə həmin database üçün lazımi cədvəl yaratma və oxuma/yazma icazələrini verin. Host, port, database adı, user və parolu saxlayın. Prefiksləri tam yazın. MySQL hostu mütləq `localhost` olmaya bilər — paneldə göstərilən dəyəri götürün.
5. Apache 2.4 və qovluq `.htaccess` giriş qaydaları işləməlidir. MySQL 8 / MariaDB 10.6+ tövsiyə edilir. PHP yaddaşı 128 MB-dan aşağı olmamalıdır, Excel üçün 256 MB tövsiyə olunur.

Hostingdə terminal, Composer, npm, Node.js və ayrıca tətbiq serveri lazım deyil.

## 2. Tam ZIP-i düzgün yerə açın

Köhnə quraşdırma ilə faylları qarışdırmayın. Lazımdırsa köhnə faylları əvvəlcə kompüterinizə arxivləyin və ya veb kökdən kənarda saxlayın. Köhnə database-i silməyin.

File Manager-də domenin veb kök qovluğuna keçin — adətən `public_html`, amma panelinizdə fərqli ola bilər. ZIP-i həmin yerə yükləyib açın. Quruluş belə olmalıdır:

```text
public_html/
  index.php
  setup.php
  health.php
  .htaccess
  app/
  assets/
  config/
  database/
  storage/
  uploads/
  vendor/
```

**Arada əlavə `mobishop/` qovluğu olmamalıdır**, əgər qəsdən alt qovluğa qurmursunuzsa. Alt qovluq seçsəniz bütün ünvanlarda onun adını da yazın.

- Gizli `.htaccess` fayllarını da çıxarın; `vendor/` və `assets/` qovluqlarını buraxmayın.
- Köhnə `config/config.php`, `storage/installed.lock`, sessiya və log fayllarını yeni paketə köçürməyin.
- `config/config.example.php` sadəcə nümunədir. Onun adını dəyişməyin: real config-i quraşdırıcı yaradacaq.
- Qovluqlar adətən `755`, fayllar `644` olur. `config/`, `storage/`, `storage/logs/`, `storage/sessions/`, `uploads/` PHP tərəfindən yazıla bilməlidir. Sahiblik səhvdirsə hosting dəstəyindən düzəliş istəyin; **777 verməyin**.
- Açılmış ZIP arxivini hostingin açıq qovluğundan silin — arxivin daxilində quraşdırma açarı var.

## 3. Əvvəl yoxlama, sonra quraşdırma

1. `https://SIZIN-DOMEN/health.php` açın. Qırmızı tələbləri düzəldin. Cookie/CSS/məxfi qovluq yoxlamalarını gözləyin.
2. `https://SIZIN-DOMEN/setup.php` açın.
3. **Quraşdırma açarı:** kompüterdə və ya File Manager-də `config/setup-key.php` faylını redaktə üçün açın. `return '...';` sətrindəki **yalnız dırnaqların arasındakı uzun dəyəri** kopyalayın. PHP kodunu və dırnaqları kopyalamayın. Faylı dəyişməyin və açarı paylaşmayın. Bu açar admin parolu deyil.
4. Açarı təsdiqləyin, yeni database məlumatlarını yazın. Bu addım bazanın boş olduğunu yoxlayır; cədvəl yaratmır.
5. Admin adı/istifadəçi adı, **12–72 simvolluq güclü parol**, ilk mağazanın adı/kodu və istəyə görə ünvan/telefon daxil edin. Azərbaycan hərfləri parolda birdən çox bayt tuta bilər; server limiti 72 baytdır.
6. İstəsəniz “İlk kassanı da aç” seçin və real açılış məbləğini yazın. Əks halda kassanın açılışını sonra moduldan edin.
7. “Sistemi qur” seçin. Tamamlanana qədər səhifəni bağlamayın. Sonda **“İş məkanınız hazırdır”** görünməlidir.
8. `index.php` ilə öz yaratdığınız hesabdan daxil olun. Təkrar quraşdırma kilidlənir.

İlkin rollar/icazələr, sistem parametrləri və xərc kateqoriyaları sxemlə gəlir. Bunlar demo biznes əməliyyatları deyil. Məhsul və sənəd cədvəlləri boş başlayır.

## 4. Yenə 500 / ağ ekran olarsa

| Görünən hal | Yoxlama |
|---|---|
| Domen açılmır, amma `index.php` açılır | Domenin veb kökünü və index prioritetini yoxlayın. `index.php` birbaşa işləyir; rewrite aktiv olduqda paket domen kökünü də ona yönləndirir. |
| `health.php` açılır, tətbiq açılmır | Oradakı PHP, modul, fayl və yazma yoxlamalarını oxuyun. Konfiqurasiya varsa açarla database yoxlamasını edin. |
| PHP versiyası uyğun deyil | Paneldə **məhz bu domen** üçün PHP 8.2+ seçin. |
| Paket natamamdır / dizayn yüklənmir | ZIP-i tam çıxarın. `app/`, `assets/`, `vendor/` və gizli `.htaccess` fayllarını yoxlayın. |
| Cookie yoxlaması uğursuz / giriş geri qayıdır | HTTPS, brauzer cookie icazəsi və `storage/sessions/` yazma icazəsini yoxlayın. Köhnə domen cookie-lərini təmizləyin. |
| Database giriş xətası | Host/user/password və hosting prefiksini yoxlayın. Database istifadəçisinin həmin bazaya bağlandığını təsdiqləyin. |
| Database boş deyil | Yeni boş baza seçin. Quraşdırıcı dolu bazanı silmir və üzərinə sxem yazmır. |
| Sistemin artıq quraşdırıldığı görünür | Köhnə config/lock qalıb və ya quraşdırma tamamlanıb. Əvvəl `index.php` ilə girişi yoxlayın; kilidi kor-koranə silməyin. |
| `health.php` özü də 500 verir | Aşağıdakı Apache səviyyəli yoxlamanı edin. |

### `health.php` də açılmırsa

1. Hosting error logunda son xətanı tapın. PHP tətbiqinə çatmadan yaranan Apache xətasını PHP özü göstərə bilməz.
2. Yalnız veb kökdəki `.htaccess` adını **müvəqqəti** `.htaccess.off` edin və birbaşa `health.php` açın. **`config/`, `storage/`, `database/`, `vendor/` daxilindəki qoruyucu `.htaccess` fayllarını silməyin.**
3. Bu dəyişiklik kömək edirsə hostunuz kök direktivlərdən birini qəbul etmir. Error logdakı konkret direktivə əsasən hosting dəstəyi ilə uyğunlaşdırın və kök qorunmanı bərpa edin. Paketin kök faylında `Options`, `php_value`, `php_flag`, məcburi `DirectoryIndex` yoxdur; lakin `AllowOverride` siyasəti hostdan asılıdır.
4. Məxfi yoxlama ünvanları `config/access-check.txt`, `storage/access-check.txt`, `database/access-check.txt`, `vendor/composer/installed.json` **403/404** qaytarmalıdır. Məzmun görünürsə saytı canlı işə salmayın.
5. Hələ də açılmırsa PHP seçimi, fayl sahiblik/icazələri və host hesabının limitlərini dəstəyə yoxlatdırın.

Tətbiqin **MS-…** xəta kodları `storage/logs/application.php` / `php-error.php` daxilində əlaqələndirilir. Logları File Manager ilə oxuyun, ictimai linklə paylaşmayın. Dəstəyə parol, setup açarı, şəxsi müştəri məlumatları və tam config göndərməyin.

### Quraşdırma ortada dayanıbsa

MySQL cədvəl yaratma əmrləri tam transaction rollback etmir. Qismən sxem qala bilər. Səhifəni dəfələrlə təsdiqləməyin və məlumat olan bazanı silməyin. Əvvəl logu yoxlayın. Yalnız bu quraşdırmaya aid boş/yarımçıq test bazası olduğuna əminsinizsə, problemi düzəldib **başqa yeni boş database** ilə başlayın. Config artıq yazılıbsa öncə `health.php` və girişlə vəziyyəti müəyyən edin.

## 5. İlk istifadə

- İlk mağaza quraşdırmada yaranır. Digərlərini **Mağazalar** bölməsindən əlavə edin.
- İşçiləri yaradın, rol və mağaza icazələrini təyin edin.
- Kateqoriya, marka, təchizatçı/müştəri və məhsul kartlarını yaradın.
- Kassa → açılış; Alış → stok; POS → satış. Satış üçün mövcud stok tələb olunur.
- Excel import üçün sistemdən şablon yükləyin. Yalnız `.xlsx`, 3 MB / 1000 sətir. Import **açılış stokudur**, alış fakturası və kassa əməliyyatı yaratmır.
- Backup SQL-ni və `uploads/` şəkillərini ayrıca, veb kökdən kənarda saxlayın. Backup bərpasını ayrıca sınaq bazasında yoxlayın.

Ətraflı iş axınları: `docs/ISTIFADE.md`. Funksiyalar və açıq məhdudiyyətlər: `docs/STATUS.md`. Yeni buraxılışın test xülasəsi: `docs/QA_2026_CLEAN.md`.

**Dürüst qeyd:** bu paket lokal Apache/PHP/MySQL mühitində sınaqdan keçirilib. Sizin GoogieHost hesabınıza yerləşdirilməyib; əvvəlki 500 xətasının konkret səbəbi server logu olmadan təsdiqlənməyib. Real uçota keçməzdən əvvəl hostunuzda giriş, alış–satış–qaytarma, backup və istifadə etdiyiniz printer/skaner ssenarilərini ayrıca test bazasında təsdiqləyin. İlkin 79 bəndin hamısının tamamlandığı iddia edilmir.
