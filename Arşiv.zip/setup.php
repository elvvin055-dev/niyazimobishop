<?php
define('MOBISHOP_ENTRY', true);
if (!is_file(__DIR__.'/app/runtime.php')) { http_response_code(503); exit('MobiShop: paket tam yuklenmeyib. app/runtime.php faylini da ZIP-den cikarin.'); }
require __DIR__.'/app/runtime.php';
mshop_safety_net();
mshop_require_runtime();
try {
    require __DIR__.'/app/bootstrap.php';
    require __DIR__.'/app/setup_wizard.php';
} catch (Throwable $error) {
    mshop_failure($error);
}
