<?php
// Legacy URL only. No setup logic lives in this subdirectory.
header('Location: ../setup.php', true, 302);
exit;
